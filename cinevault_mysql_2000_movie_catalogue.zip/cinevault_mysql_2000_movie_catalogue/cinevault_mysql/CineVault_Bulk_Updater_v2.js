'use strict';

/**
 * CineVault bulk metadata enrichment (TMDB), version 2.
 * Truncates fetched descriptions to the actual MySQL column character limit.
 *
 * - Uses the project's existing MySQL .env settings.
 * - Queries only active movie rows missing year, genre, or rating.
 * - Writes a JSON backup before any database changes.
 * - Updates only exact normalized title matches with a compatible original language.
 * - Skips ambiguous and uncertain matches instead of guessing.
 * - Never updates booking, show, seat, or booking-seat tables.
 *
 * Requires Node.js 18+ (global fetch), mysql2, and dotenv already in the project.
 */

require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const mysql = require('mysql2/promise');

const TMDB_TOKEN = (process.env.TMDB_API_TOKEN || '').trim();
const TMDB_BASE = 'https://api.themoviedb.org/3';
const IMAGE_BASE = 'https://image.tmdb.org/t/p/w500';
const CONCURRENCY = 3;
const REQUEST_GAP_MS = 250;
const MAX_RETRIES = 5;

const EXPECTED_LANGUAGES = {
  Telugu: new Set(['te']),
  Hindi: new Set(['hi']),
  English: new Set(['en']),
  Tamil: new Set(['ta']),
  Kannada: new Set(['kn']),
  Malayalam: new Set(['ml']),
  Korean: new Set(['ko']),
};

const TMDB_GENRES = {
  28: 'Action',
  12: 'Adventure',
  16: 'Animation',
  35: 'Comedy',
  80: 'Crime',
  99: 'Documentary',
  18: 'Drama',
  10751: 'Family',
  14: 'Fantasy',
  36: 'History',
  27: 'Horror',
  10402: 'Music',
  9648: 'Mystery',
  10749: 'Romance',
  878: 'Science Fiction',
  10770: 'TV Movie',
  53: 'Thriller',
  10752: 'War',
  37: 'Western',
};

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function normalizeTitle(value) {
  return String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, '');
}

function yearFromReleaseDate(releaseDate) {
  const match = String(releaseDate || '').match(/^(\d{4})-/);
  if (!match) return null;
  const year = Number(match[1]);
  return year >= 1888 && year <= new Date().getFullYear() + 2 ? year : null;
}

async function tmdbGet(url, attempt = 0) {
  await sleep(REQUEST_GAP_MS);
  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${TMDB_TOKEN}`,
      Accept: 'application/json',
    },
  });

  if (response.status === 429 || response.status >= 500) {
    if (attempt >= MAX_RETRIES) {
      throw new Error(`TMDB API returned HTTP ${response.status} after retries`);
    }
    const retryAfter = Number(response.headers.get('retry-after'));
    const backoff = Number.isFinite(retryAfter) && retryAfter > 0
      ? retryAfter * 1000
      : Math.min(1000 * (2 ** attempt), 15000);
    await sleep(backoff);
    return tmdbGet(url, attempt + 1);
  }

  if (!response.ok) {
    const body = await response.text().catch(() => '');
    throw new Error(`TMDB API HTTP ${response.status}: ${body.slice(0, 250)}`);
  }
  return response.json();
}

function findExactCandidate(row, results) {
  const target = normalizeTitle(row.title);
  const candidates = (results || []).filter((candidate) => {
    const titleMatch = normalizeTitle(candidate.title) === target
      || normalizeTitle(candidate.original_title) === target;
    if (!titleMatch) return false;

    const allowed = EXPECTED_LANGUAGES[row.language];
    // For known catalogue languages, require a matching original language.
    // This avoids silently filling a dubbed/ambiguous title with the wrong film.
    if (allowed && !allowed.has(candidate.original_language)) return false;
    return true;
  });

  if (candidates.length === 0) return { match: null, reason: 'no exact title + language match' };

  // If the same exact title has multiple matching-language releases, do not guess.
  const distinctYears = new Set(candidates.map((c) => yearFromReleaseDate(c.release_date)).filter(Boolean));
  if (distinctYears.size > 1) {
    return { match: null, reason: `ambiguous exact title (${[...distinctYears].sort().join(', ')})` };
  }

  // Same title and same year can occasionally be alternate entries. Prefer the
  // result with more votes, but still require the year to agree if both have one.
  candidates.sort((a, b) => (Number(b.vote_count) || 0) - (Number(a.vote_count) || 0));
  return { match: candidates[0], reason: 'exact title + language match' };
}

function getPrimaryGenre(candidate) {
  for (const genreId of (candidate.genre_ids || [])) {
    if (TMDB_GENRES[genreId]) return TMDB_GENRES[genreId];
  }
  return null;
}

function fitTextToColumn(value, maxChars) {
  const text = String(value || '').trim();
  if (!maxChars || maxChars < 1) return text;
  const chars = Array.from(text);
  if (chars.length <= maxChars) return text;
  if (maxChars === 1) return '…';
  return chars.slice(0, maxChars - 1).join('').trimEnd() + '…';
}

async function main() {
  if (typeof fetch !== 'function') {
    throw new Error('Node.js 18 or newer is required (for built-in fetch).');
  }
  if (!TMDB_TOKEN) {
    throw new Error(
      'Missing TMDB_API_TOKEN. Add your TMDB API Read Access Token to the project .env file. Do not share it in chat.'
    );
  }

  const pool = mysql.createPool({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'cinevault',
    waitForConnections: true,
    connectionLimit: 5,
    queueLimit: 0,
    charset: 'utf8mb4',
  });

  try {
    const [descriptionColumns] = await pool.query(`
      SELECT DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = 'movies'
        AND COLUMN_NAME = 'description'
      LIMIT 1
    `);
    const rawDescriptionLimit = descriptionColumns[0]?.CHARACTER_MAXIMUM_LENGTH;
    const descriptionLimit = rawDescriptionLimit == null ? null : Number(rawDescriptionLimit);
    if (descriptionLimit) {
      console.log(`Description text will be limited to ${descriptionLimit} characters to fit the database column.`);
    } else {
      console.log('Description column limit could not be determined; descriptions will be written without truncation.');
    }

    const [rows] = await pool.query(`
      SELECT id, title, language, release_year, genre, rating, image_url, description
      FROM movies
      WHERE is_active = 1
        AND (
          release_year = 0
          OR genre IS NULL OR genre = '' OR genre = 'Unclassified'
          OR rating IS NULL OR rating = 0
        )
      ORDER BY language, id
    `);

    if (!rows.length) {
      console.log('No active movie rows need year, genre, or rating enrichment.');
      return;
    }

    const projectDir = process.cwd();
    const backupDir = path.join(projectDir, 'backups');
    fs.mkdirSync(backupDir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupPath = path.join(backupDir, `cinevault-movies-before-enrichment-${stamp}.json`);
    fs.writeFileSync(backupPath, JSON.stringify(rows, null, 2), 'utf8');
    console.log(`Backup saved: ${path.relative(projectDir, backupPath)}`);
    console.log(`Checking ${rows.length} active movies with incomplete metadata...`);
    console.log('Only exact title + compatible original-language matches will be updated.');

    let nextIndex = 0;
    let processed = 0;
    let updated = 0;
    let skipped = 0;
    let failures = 0;
    const examples = [];

    async function worker() {
      while (true) {
        const index = nextIndex++;
        if (index >= rows.length) return;
        const row = rows[index];
        processed++;

        try {
          const url = new URL(`${TMDB_BASE}/search/movie`);
          url.searchParams.set('query', row.title);
          url.searchParams.set('include_adult', 'false');
          url.searchParams.set('language', 'en-US');
          url.searchParams.set('page', '1');
          const search = await tmdbGet(url.toString());
          const outcome = findExactCandidate(row, search.results);
          if (!outcome.match) {
            skipped++;
            if (examples.length < 20) examples.push({ id: row.id, title: row.title, result: outcome.reason });
            continue;
          }

          const candidate = outcome.match;
          const year = yearFromReleaseDate(candidate.release_date);
          const genre = getPrimaryGenre(candidate);
          const score = Number(candidate.vote_average) || 0;
          const voteCount = Number(candidate.vote_count) || 0;
          const rating = score > 0 && voteCount >= 5 ? Math.round(score * 10) / 10 : null;
          const posterUrl = candidate.poster_path ? `${IMAGE_BASE}${candidate.poster_path}` : null;
          const overview = fitTextToColumn(candidate.overview || '', descriptionLimit);
          const assignments = [];
          const params = [];

          if (Number(row.release_year) === 0 && year) {
            assignments.push('release_year = ?'); params.push(year);
          }
          if ((!row.genre || row.genre === 'Unclassified') && genre) {
            assignments.push('genre = ?'); params.push(genre);
          }
          if ((row.rating == null || Number(row.rating) === 0) && rating != null) {
            assignments.push('rating = ?'); params.push(rating);
          }
          // Refresh poster URL for matched incomplete records when TMDB has a poster.
          if (posterUrl) {
            assignments.push('image_url = ?'); params.push(posterUrl);
          }
          if (overview && (!row.description || row.description.startsWith('Catalogue entry imported from the supplied title list.'))) {
            assignments.push('description = ?'); params.push(overview);
          }

          if (!assignments.length) {
            skipped++;
            continue;
          }

          params.push(row.id);
          const [result] = await pool.execute(
            `UPDATE movies SET ${assignments.join(', ')} WHERE id = ? AND is_active = 1`,
            params
          );
          if (result.affectedRows > 0) updated++;
          else skipped++;

          if (processed % 25 === 0) {
            console.log(`Progress: ${processed}/${rows.length}; updated ${updated}; skipped ${skipped}; errors ${failures}`);
          }
        } catch (error) {
          failures++;
          if (examples.length < 20) examples.push({ id: row.id, title: row.title, result: `error: ${error.message}` });
        }
      }
    }

    await Promise.all(Array.from({ length: Math.min(CONCURRENCY, rows.length) }, () => worker()));

    console.log('\n=== CineVault metadata enrichment summary (v2) ===');
    console.log(`Rows checked: ${rows.length}`);
    console.log(`Rows updated: ${updated}`);
    console.log(`Rows skipped (not an exact/usable match): ${skipped}`);
    console.log(`Errors: ${failures}`);
    console.log(`Backup: ${path.relative(projectDir, backupPath)}`);
    if (examples.length) {
      console.log('\nSample skipped/error rows (first 20):');
      for (const item of examples) console.log(`- ${item.id} | ${item.title} | ${item.result}`);
    }
    console.log('\nRatings come from TMDB vote_average on a 10-point scale and are only applied when vote_count >= 5.');
    console.log('Long descriptions are trimmed to fit the movies.description column.');
    console.log('This script does not change bookings, shows, seats, or show_seats.');
  } finally {
    await pool.end();
  }
}

main().catch((error) => {
  console.error(`\nCineVault enrichment stopped: ${error.message}`);
  process.exitCode = 1;
});
