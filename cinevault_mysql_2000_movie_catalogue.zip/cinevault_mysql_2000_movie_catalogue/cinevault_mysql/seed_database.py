"""Seed CineVault with a broad demo catalogue and the next 7 days of shows.

Run after database/schema.sql has been executed in MySQL Workbench.
Values such as ratings and ticket prices are illustrative demo data, not live listings.
"""
from __future__ import annotations
import os
import csv
import re
import unicodedata
from datetime import date, timedelta
from pathlib import Path

import mysql.connector
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")
DB_CONFIG = {
    "host": os.getenv("MYSQL_HOST", "127.0.0.1"),
    "port": int(os.getenv("MYSQL_PORT", "3306")),
    "user": os.getenv("MYSQL_USER", "root"),
    "password": os.getenv("MYSQL_PASSWORD", ""),
    "database": os.getenv("MYSQL_DATABASE", "cinevault"),
    "charset": "utf8mb4",
}

# The original six CineVault demo titles are kept. The rest are well-known titles
# so the search feels useful; all prices/ratings/tags are project-demo values.
MOVIE_ROWS = [
    ("velvet", "Velvet Horizon", "Drama", 2026, "2h 08m", 8.9, 240, "EDITOR’S PICK", "A pianist returns to a city that remembers every note.", "linear-gradient(145deg,#302e5a,#755b8b 48%,#d69b8d)", "#b6a8ff", "#f0c4d2", "#e8c6c8", "https://images.unsplash.com/photo-1516280440614-37939bbacd81?auto=format&fit=crop&w=900&q=85", "English", "UA", 1),
    ("orbit", "Orbit Nine", "Sci-Fi", 2026, "2h 16m", 9.1, 280, "BIG SCREEN", "Nine minutes to save a world no one can see.", "linear-gradient(145deg,#142d47,#2c7887 55%,#e2b986)", "#53c3d1", "#d8f5ef", "#a2e8e9", "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=900&q=85", "English", "UA", 1),
    ("scarlet", "A Study in Scarlet", "Mystery", 2025, "1h 58m", 8.7, 220, "MYSTERY NIGHT", "One letter. Three suspects. A city full of secrets.", "linear-gradient(145deg,#421f35,#a44f59 50%,#e3a26f)", "#ed826d", "#f6d3a0", "#f2b69b", "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=900&q=85", "English", "UA", 1),
    ("wildwood", "Wildwood", "Fantasy", 2026, "2h 04m", 8.8, 260, "FAN FAVOURITE", "Beyond the last lantern, the forest starts dreaming.", "linear-gradient(145deg,#173c3c,#43806e 55%,#d5bd8b)", "#8dd6b4", "#e2e6a5", "#c9e6b9", "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=900&q=85", "English", "UA", 1),
    ("afterrain", "After the Rain", "Romance", 2025, "1h 52m", 8.5, 200, "FEEL SOMETHING", "Two strangers. One monsoon. A thousand almosts.", "linear-gradient(145deg,#29375b,#7a7cb3 48%,#e0a4a1)", "#a4b5f4", "#f3d3ce", "#f3c1c6", "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=900&q=85", "English", "UA", 1),
    ("silent", "The Silent Orbit", "Thriller", 2026, "2h 11m", 8.6, 250, "EDGE OF YOUR SEAT", "The signal is coming from somewhere inside the ship.", "linear-gradient(145deg,#20263e,#4a536c 50%,#9b7d8c)", "#c2b4dc", "#e5d8ee", "#d8c4e8", "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=900&q=85", "English", "UA", 1),
]

EXTRAS = [
    ("inception", "Inception", "Sci-Fi", 2010, "2h 28m", 8.8, 260, "MIND-BENDING", "A skilled team enters layered dreams for an impossible mission.", "English", "UA"),
    ("interstellar", "Interstellar", "Sci-Fi", 2014, "2h 49m", 8.7, 280, "COSMIC JOURNEY", "A desperate voyage searches for a future among the stars.", "English", "UA"),
    ("avatar", "Avatar", "Fantasy", 2009, "2h 42m", 7.9, 260, "OTHER WORLDS", "An outsider discovers a living world beyond his own.", "English", "UA"),
    ("dune2", "Dune: Part Two", "Sci-Fi", 2024, "2h 46m", 8.5, 300, "EPIC SCALE", "A young leader faces destiny across a vast desert planet.", "English", "UA"),
    ("darkknight", "The Dark Knight", "Action", 2008, "2h 32m", 9.0, 250, "LEGENDARY", "A city tests the limits of courage and justice.", "English", "UA"),
    ("spiderverse", "Spider-Man: Across the Spider-Verse", "Animation", 2023, "2h 20m", 8.6, 250, "MULTIVERSE MAGIC", "A hero leaps across realities and impossible choices.", "English", "U"),
    ("insideout2", "Inside Out 2", "Animation", 2024, "1h 36m", 7.6, 220, "FAMILY PICK", "A familiar inner world grows more complicated with new feelings.", "English", "U"),
    ("coco", "Coco", "Animation", 2017, "1h 45m", 8.4, 220, "HEARTWARMING", "Music leads a young dreamer into a colourful family mystery.", "English", "U"),
    ("frozen2", "Frozen II", "Animation", 2019, "1h 43m", 6.8, 220, "SING-ALONG", "Two sisters follow a mysterious call beyond their kingdom.", "English", "U"),
    ("jurassicpark", "Jurassic Park", "Adventure", 1993, "2h 07m", 8.2, 230, "ADVENTURE CLASSIC", "A dream attraction turns into a race to survive.", "English", "UA"),
    ("harrypotter1", "Harry Potter and the Philosopher's Stone", "Fantasy", 2001, "2h 32m", 7.7, 250, "MAGICAL CLASSIC", "A young newcomer discovers a hidden school of magic.", "English", "U"),
    ("lotr", "The Lord of the Rings: The Fellowship of the Ring", "Fantasy", 2001, "2h 58m", 8.8, 280, "FANTASY EPIC", "An unlikely fellowship begins a dangerous journey.", "English", "UA"),
    ("titanic", "Titanic", "Romance", 1997, "3h 14m", 7.9, 240, "TIMELESS ROMANCE", "Two lives cross paths aboard a legendary voyage.", "English", "UA"),
    ("lalaland", "La La Land", "Romance", 2016, "2h 08m", 8.0, 230, "MUSIC & DREAMS", "Two artists chase ambition and connection in Los Angeles.", "English", "U"),
    ("grandbudapest", "The Grand Budapest Hotel", "Comedy", 2014, "1h 39m", 8.1, 220, "QUIRKY FAVOURITE", "A concierge and his protégé are caught in a caper.", "English", "UA"),
    ("knivesout", "Knives Out", "Mystery", 2019, "2h 10m", 7.9, 230, "WHODUNNIT", "A detective unpicks a wealthy family's tangled secrets.", "English", "UA"),
    ("parasite", "Parasite", "Thriller", 2019, "2h 12m", 8.5, 240, "AWARD WINNER", "Two families' worlds collide in an unsettling game of class.", "Korean", "A"),
    ("martian", "The Martian", "Adventure", 2015, "2h 24m", 8.0, 250, "SURVIVAL STORY", "An astronaut improvises a way to survive far from home.", "English", "UA"),
    ("topgunmaverick", "Top Gun: Maverick", "Action", 2022, "2h 10m", 8.2, 270, "HIGH-OCTANE", "An elite pilot returns to train a new generation.", "English", "UA"),
    ("oppenheimer", "Oppenheimer", "Drama", 2023, "3h 00m", 8.3, 280, "BIG-SCREEN DRAMA", "A brilliant scientist confronts the consequences of his work.", "English", "A"),
    ("barbie", "Barbie", "Comedy", 2023, "1h 54m", 6.8, 240, "PINK PREMIERE", "A perfect-looking world inspires an unexpected journey.", "English", "UA"),
    ("thebatman", "The Batman", "Action", 2022, "2h 56m", 7.8, 260, "DARK & GRITTY", "A detective follows a trail of clues through a rain-soaked city.", "English", "UA"),
    ("everythingeverywhere", "Everything Everywhere All at Once", "Adventure", 2022, "2h 19m", 7.8, 250, "REALITY-BENDING", "An ordinary woman faces an extraordinary multiverse crisis.", "English", "A"),
    ("shawshank", "The Shawshank Redemption", "Drama", 1994, "2h 22m", 9.3, 220, "ALL-TIME CLASSIC", "A friendship endures through years of hardship and hope.", "English", "A"),
    ("rrr", "RRR", "Action", 2022, "3h 07m", 7.8, 280, "INDIAN BLOCKBUSTER", "Two bold revolutionaries become part of a larger-than-life story.", "Telugu", "UA"),
    ("baahubali", "Baahubali: The Beginning", "Action", 2015, "2h 39m", 8.0, 250, "GRAND SPECTACLE", "A young warrior uncovers a kingdom's extraordinary past.", "Telugu", "UA"),
    ("3idiots", "3 Idiots", "Comedy", 2009, "2h 50m", 8.4, 220, "CROWD FAVOURITE", "Three friends question the rules of education and success.", "Hindi", "U"),
    ("dangal", "Dangal", "Drama", 2016, "2h 41m", 8.3, 230, "INSPIRING", "A determined family challenges expectations through sport.", "Hindi", "U"),
    ("kgf", "K.G.F: Chapter 1", "Action", 2018, "2h 35m", 8.2, 250, "MASS ACTION", "An ambitious outsider rises in a dangerous gold-mining empire.", "Kannada", "UA"),
    ("sitaramam", "Sita Ramam", "Romance", 2022, "2h 43m", 8.5, 230, "LOVE LETTER", "A mysterious letter connects two lives across time.", "Telugu", "U"),
    ("drishyam", "Drishyam", "Mystery", 2013, "2h 40m", 8.2, 220, "SUSPENSE PICK", "A family man uses careful planning to protect his family.", "Malayalam", "U"),
    ("pushpa", "Pushpa: The Rise", "Action", 2021, "2h 59m", 7.6, 260, "POWER PLAY", "An ambitious smuggler climbs through a risky underworld.", "Telugu", "A"),
    ("kantara", "Kantara", "Thriller", 2022, "2h 28m", 8.2, 240, "FOLK THRILLER", "A village's traditions and power struggles collide.", "Kannada", "UA"),
    ("kalki", "Kalki 2898 AD", "Sci-Fi", 2024, "3h 01m", 7.1, 300, "FUTURE EPIC", "A futuristic world searches for hope amid an ancient prophecy.", "Telugu", "UA"),
]

PALETTES = [
    ("linear-gradient(145deg,#3a2348,#914e72 52%,#f0b57c)", "#eaa0c4", "#f8dfb4", "#f2a7bd"),
    ("linear-gradient(145deg,#183d43,#2d8079 52%,#e6bd72)", "#7ce0c4", "#e8f4bd", "#b1e8d4"),
    ("linear-gradient(145deg,#281f52,#7651b2 52%,#e3a2c2)", "#b7a3ff", "#f4d6f2", "#e2b5ff"),
    ("linear-gradient(145deg,#4a1d31,#a3404e 52%,#e9a35d)", "#ff907c", "#ffdf9d", "#f7b19b"),
    ("linear-gradient(145deg,#1b304f,#416f98 52%,#d7b78b)", "#9cd7ff", "#f6e6b9", "#a9d9f1"),
    ("linear-gradient(145deg,#183d2d,#4f8557 52%,#d4c47a)", "#9fe0a8", "#eff0b5", "#c1e4a7"),
    ("linear-gradient(145deg,#3a254f,#7c477e 52%,#d28e83)", "#d9a5ff", "#f7d3cd", "#e8a9c9"),
    ("linear-gradient(145deg,#1f2739,#536078 52%,#b47f7f)", "#c1c7ed", "#f0d3d4", "#c8b7dd"),
]
IMAGES = [
    "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=900&q=85",
    "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=900&q=85",
    "https://images.unsplash.com/photo-1516280440614-37939bbacd81?auto=format&fit=crop&w=900&q=85",
    "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=900&q=85",
    "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=900&q=85",
    "https://images.unsplash.com/photo-1518837695005-2083093ee35b?auto=format&fit=crop&w=900&q=85",
    "https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?auto=format&fit=crop&w=900&q=85",
    "https://images.unsplash.com/photo-1511497584788-876760111969?auto=format&fit=crop&w=900&q=85",
]


def _normalise_title(value: str) -> str:
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    return re.sub(r"[^a-z0-9]+", "", value.lower())


def all_movies():
    """Return curated demo records plus the deduplicated catalogue supplied by the user."""
    rows = list(MOVIE_ROWS)
    for i, item in enumerate(EXTRAS):
        mid, title, genre, year, duration, rating, price, tag, desc, language, certificate = item
        bg, orb, orb_light, accent = PALETTES[i % len(PALETTES)]
        image = IMAGES[i % len(IMAGES)]
        rows.append((mid, title, genre, year, duration, rating, price, tag, desc, bg, orb, orb_light, accent, image, language, certificate, 0))

    seen = {(_normalise_title(row[1]), row[14].casefold()) for row in rows}
    catalogue_path = ROOT / "database" / "movie_catalogue.csv"
    with catalogue_path.open("r", encoding="utf-8-sig", newline="") as catalogue_file:
        for index, record in enumerate(csv.DictReader(catalogue_file)):
            title = record["title"].strip()
            language = record["language"].strip() or "Unknown"
            key = (_normalise_title(title), language.casefold())
            if not title or key in seen:
                continue
            seen.add(key)
            palette_index = (index + 3) % len(PALETTES)
            bg, orb, orb_light, accent = PALETTES[palette_index]
            image = IMAGES[index % len(IMAGES)]
            movie_id = f"catalog-{int(record['source_number']):04d}"
            rows.append((movie_id, title, record.get("genre") or "Unclassified",
                         int(record.get("release_year") or 0), record.get("duration") or "Not listed",
                         float(record.get("rating") or 0), int(record.get("base_price") or 220),
                         record.get("tag") or "CATALOGUE", record.get("description") or "Catalogue entry imported from the supplied title list.",
                         bg, orb, orb_light, accent, image, language, record.get("certificate") or "NR", 0))
    return rows


def main():
    connection = mysql.connector.connect(**DB_CONFIG)
    cursor = connection.cursor()
    try:
        movie_sql = """INSERT INTO movies
          (id,title,genre,release_year,duration,rating,base_price,tag,description,bg,orb,orb_light,accent,image_url,language,certificate,featured)
          VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
          ON DUPLICATE KEY UPDATE title=VALUES(title), genre=VALUES(genre), release_year=VALUES(release_year),
          duration=VALUES(duration), rating=VALUES(rating), base_price=VALUES(base_price), tag=VALUES(tag),
          description=VALUES(description), bg=VALUES(bg), orb=VALUES(orb), orb_light=VALUES(orb_light),
          accent=VALUES(accent), image_url=VALUES(image_url), language=VALUES(language), certificate=VALUES(certificate),
          featured=VALUES(featured), is_active=1"""
        cursor.executemany(movie_sql, all_movies())

        screens = [
            ("screen-01", "Screen 01", "The Grand", "Dolby Atmos,4K Projection,AC"),
            ("screen-02", "Screen 02", "The Velvet Room", "Surround Sound,Laser Projection,AC"),
            ("screen-03", "Screen 03", "The Indie House", "Immersive Sound,Classic Seating,Flexible AC"),
        ]
        cursor.executemany("""INSERT INTO screens (id,name,label,features) VALUES (%s,%s,%s,%s)
          ON DUPLICATE KEY UPDATE label=VALUES(label), features=VALUES(features), is_active=1""", screens)

        seat_rows = []
        for screen_id, *_ in screens:
            for row_label in "ABCDEF":
                zone = "front" if row_label in "AB" else "center" if row_label in "CD" else "recliner"
                seat_type = "Standard" if zone == "front" else "Premium" if zone == "center" else "Recliner"
                for number in range(1, 9):
                    seat_id = f"{row_label}{number}"
                    seat_rows.append((screen_id, seat_id, row_label, number, zone, seat_type, int(number in (1, 8)), int(number in (3, 4, 5, 6))))
        cursor.executemany("""INSERT IGNORE INTO seats
          (screen_id,seat_id,row_label,seat_number,zone,seat_type,is_aisle,is_center)
          VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""", seat_rows)

        # Keep the original first-week demo schedule stable for existing installs.
        # These curated records repeat during week one, matching the earlier 40-movie build.
        cursor.execute("SELECT id, base_price FROM movies WHERE is_active=1 AND id NOT LIKE 'catalog-%' ORDER BY featured DESC, title")
        curated_movies = cursor.fetchall()
        cursor.execute("SELECT id, base_price FROM movies WHERE is_active=1 ORDER BY featured DESC, title")
        all_catalogue_movies = cursor.fetchall()
        if not all_catalogue_movies:
            raise RuntimeError("No movies were inserted; check database/schema.sql and database/movie_catalogue.csv.")
        show_slots = [("screen-01", "15:15:00"), ("screen-01", "18:30:00"), ("screen-01", "20:45:00"),
                      ("screen-02", "15:15:00"), ("screen-02", "18:30:00"), ("screen-02", "20:45:00"),
                      ("screen-03", "15:15:00"), ("screen-03", "18:30:00"), ("screen-03", "20:45:00")]
        today = date.today()
        show_insert = """INSERT IGNORE INTO shows (id,movie_id,screen_id,show_date,show_time,base_price)
          VALUES (%s,%s,%s,%s,%s,%s)"""
        show_seat_insert = "INSERT IGNORE INTO show_seats (show_id,screen_id,seat_id,status) VALUES (%s,%s,%s,'available')"
        total_shows = 0

        def schedule_range(movie_rows, day_offsets):
            nonlocal total_shows
            slot_number = 0
            for day_offset in day_offsets:
                show_date = today + timedelta(days=day_offset)
                for screen_id, show_time in show_slots:
                    movie_id, base_price = movie_rows[slot_number % len(movie_rows)]
                    time_compact = show_time.replace(":", "")
                    show_id = f"show-{movie_id}-{screen_id}-{show_date:%Y%m%d}-{time_compact}"
                    cursor.execute(show_insert, (show_id, movie_id, screen_id, show_date, show_time, int(base_price)))
                    cursor.execute("SELECT COUNT(*) FROM shows WHERE id=%s", (show_id,))
                    if cursor.fetchone()[0]:
                        cursor.executemany(show_seat_insert, [(show_id, screen_id, f"{r}{n}") for r in "ABCDEF" for n in range(1, 9)])
                    total_shows += 1
                    slot_number += 1

        # First week: familiar curated titles. Following 60 days: every catalogue title
        # receives at least one generated demo screening, so the full list can be tested end-to-end.
        if curated_movies:
            schedule_range(curated_movies, range(7))
        schedule_range(all_catalogue_movies, range(7, 67))
        connection.commit()
        print("CineVault database seeded successfully.")
        print(f"Movies in catalogue: {len(all_movies())} (40 curated/demo records plus unique titles from your supplied list where not already represented)")
        print(f"Physical screens: {len(screens)} · Seats per screen: 48")
        print(f"Demo show slots prepared (first week + next 60-day catalogue rotation): {total_shows}")
        print("Imported catalogue metadata is marked unknown where your source list did not provide it.")
        print("All generated showtimes and ₹220 catalogue prices are demo data, not real cinema listings.")
    except Exception:
        connection.rollback()
        raise
    finally:
        cursor.close()
        connection.close()

if __name__ == "__main__":
    main()
