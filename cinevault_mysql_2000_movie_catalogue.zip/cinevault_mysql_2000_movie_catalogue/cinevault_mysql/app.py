"""CineVault API backed by MySQL 8.0+ (database phase)."""
from __future__ import annotations
import os
import re
import secrets
from datetime import date, datetime, time
from pathlib import Path
from typing import Any

import mysql.connector
from dotenv import load_dotenv
from flask import Flask, jsonify, request, send_from_directory
from mysql.connector import IntegrityError, Error as MySQLError

BASE_DIR = Path(__file__).resolve().parent
FRONTEND_DIR = BASE_DIR / "frontend"
load_dotenv(BASE_DIR / ".env")

DB_CONFIG = {
    "host": os.getenv("MYSQL_HOST", "127.0.0.1"),
    "port": int(os.getenv("MYSQL_PORT", "3306")),
    "user": os.getenv("MYSQL_USER", "root"),
    "password": os.getenv("MYSQL_PASSWORD", ""),
    "database": os.getenv("MYSQL_DATABASE", "cinevault"),
    "charset": "utf8mb4",
    "connection_timeout": 5,
}

app = Flask(__name__, static_folder=str(FRONTEND_DIR), static_url_path="")
app.config["JSON_SORT_KEYS"] = False


def connect_db():
    return mysql.connector.connect(**DB_CONFIG)


def api_error(message: str, status: int = 400):
    return jsonify({"error": message}), status


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug[:55] or f"movie-{secrets.token_hex(4)}"


def iso_date(value):
    return value.isoformat() if isinstance(value, (date, datetime)) else str(value)


def time_text(value):
    if isinstance(value, time):
        return value.strftime("%H:%M")
    return str(value)[:5]


def movie_dict(row: dict[str, Any]) -> dict[str, Any]:
    raw_year = row["release_year"]
    raw_rating = row["rating"]
    return {
        "id": row["id"], "title": row["title"], "genre": row["genre"],
        "year": int(raw_year) if raw_year and int(raw_year) > 0 else None,
        "duration": row["duration"],
        "rating": f"{float(raw_rating):.1f}" if raw_rating is not None and float(raw_rating) > 0 else None,
        "price": int(row["base_price"]),
        "tag": row["tag"], "desc": row["description"], "bg": row["bg"],
        "orb": row["orb"], "orbLight": row["orb_light"], "accent": row["accent"],
        "image": row["image_url"], "language": row["language"],
        "certificate": row["certificate"], "featured": bool(row["featured"]),
    }


def fetch_all(sql, params=()):
    connection = connect_db()
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute(sql, params)
        return cursor.fetchall()
    finally:
        connection.close()


def get_show(show_id: str):
    rows = fetch_all("""SELECT sh.id, sh.movie_id, m.title AS movie_title,
        sh.screen_id, sc.name AS screen, sc.label AS screen_label,
        sh.show_date, sh.show_time, sh.base_price,
        (SELECT COUNT(*) FROM seats s WHERE s.screen_id=sh.screen_id) AS capacity
        FROM shows sh JOIN movies m ON m.id=sh.movie_id JOIN screens sc ON sc.id=sh.screen_id
        WHERE sh.id=%s AND m.is_active=1 AND sc.is_active=1""", (show_id,))
    if not rows:
        return None
    row = rows[0]
    return {
        "id": row["id"], "movie_id": row["movie_id"], "movie_title": row["movie_title"],
        "screen_id": row["screen_id"], "screen": row["screen"], "screen_label": row["screen_label"],
        "date": iso_date(row["show_date"]), "show_date": iso_date(row["show_date"]),
        "time": time_text(row["show_time"]), "capacity": int(row["capacity"]),
        "base_price": int(row["base_price"]),
    }


def seat_zone(row_label: str) -> str:
    return "front" if row_label in "AB" else "center" if row_label in "CD" else "recliner"


def zone_extra(zone: str) -> int:
    return {"front": 0, "center": 30, "recliner": 60}.get(zone, 0)


def seat_price(base_price: int, zone: str, experience: str) -> int:
    return int(base_price) + zone_extra(zone) + (30 if experience == "ac" else 0)


@app.get("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.get("/api/health")
def health():
    connection = connect_db()
    try:
        cursor = connection.cursor()
        cursor.execute("SELECT 1")
        cursor.fetchone()
        return jsonify({"status": "ok", "service": "CineVault API", "storage": "MySQL", "database_connected": True})
    finally:
        connection.close()


@app.get("/api/movies")
def get_movies():
    query = request.args.get("q", "").strip()
    genre = request.args.get("genre", "all").strip()
    language = request.args.get("language", "all").strip()
    sort = request.args.get("sort", "featured").strip().lower()
    where = ["is_active=1"]
    params: list[Any] = []
    if query:
        where.append("(title LIKE %s OR genre LIKE %s OR description LIKE %s OR language LIKE %s OR (release_year > 0 AND CAST(release_year AS CHAR) LIKE %s))")
        wildcard = f"%{query}%"
        params.extend([wildcard] * 5)
    if genre and genre.lower() != "all":
        where.append("LOWER(genre)=LOWER(%s)")
        params.append(genre)
    if language and language.lower() != "all":
        where.append("LOWER(language)=LOWER(%s)")
        params.append(language)
    where_sql = " AND ".join(where)
    order_by = {
        "featured": "featured DESC, (release_year=0) ASC, title ASC",
        "rating": "(rating=0) ASC, rating DESC, title ASC",
        "price": "base_price ASC, title ASC",
        "title": "title ASC",
        "year": "(release_year=0) ASC, release_year DESC, title ASC",
    }.get(sort, "featured DESC, (release_year=0) ASC, title ASC")
    # Paginated mode is used by the website so thousands of catalogue records do not
    # need to be rendered in one giant DOM. Legacy callers without limit still get an array.
    if "limit" in request.args:
        try:
            limit = max(1, min(100, int(request.args.get("limit", "24"))))
            offset = max(0, int(request.args.get("offset", "0")))
        except ValueError:
            return api_error("limit and offset must be whole numbers.")
        count_rows = fetch_all(f"SELECT COUNT(*) AS total FROM movies WHERE {where_sql}", tuple(params))
        total = int(count_rows[0]["total"] if count_rows else 0)
        rows = fetch_all(f"SELECT * FROM movies WHERE {where_sql} ORDER BY {order_by} LIMIT %s OFFSET %s", tuple(params + [limit, offset]))
        return jsonify({"items": [movie_dict(row) for row in rows], "total": total, "limit": limit, "offset": offset})
    rows = fetch_all(f"SELECT * FROM movies WHERE {where_sql} ORDER BY {order_by}", tuple(params))
    return jsonify([movie_dict(row) for row in rows])


@app.post("/api/movies")
def add_movie():
    """Simple admin/demo endpoint to add a title to the searchable catalogue."""
    payload = request.get_json(silent=True) or {}
    title = str(payload.get("title", "")).strip()
    genre = str(payload.get("genre", "")).strip()
    description = str(payload.get("desc", payload.get("description", ""))).strip()
    if not title or not genre or not description:
        return api_error("Title, genre and description are required.")
    movie_id = slugify(str(payload.get("id") or title))
    colors = {
        "bg": str(payload.get("bg", "linear-gradient(145deg,#302e5a,#755b8b 48%,#d69b8d)")),
        "orb": str(payload.get("orb", "#b6a8ff")),
        "orb_light": str(payload.get("orbLight", "#f0c4d2")),
        "accent": str(payload.get("accent", "#e8c6c8")),
    }
    connection = connect_db()
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""INSERT INTO movies
            (id,title,genre,release_year,duration,rating,base_price,tag,description,bg,orb,orb_light,accent,image_url,language,certificate,featured)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,0)""",
            (movie_id, title, genre, int(payload.get("year", date.today().year)),
             str(payload.get("duration", "2h 00m")), float(payload.get("rating", 8.0)),
             max(1, int(payload.get("price", 220))), str(payload.get("tag", "NOW SHOWING")), description,
             colors["bg"], colors["orb"], colors["orb_light"], colors["accent"],
             str(payload.get("image", "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=900&q=85")),
             str(payload.get("language", "English")), str(payload.get("certificate", "UA"))))
        connection.commit()
        cursor.execute("SELECT * FROM movies WHERE id=%s", (movie_id,))
        return jsonify(movie_dict(cursor.fetchone())), 201
    except IntegrityError:
        connection.rollback()
        return api_error("A movie with that ID already exists. Try a different ID or title.", 409)
    finally:
        connection.close()


@app.get("/api/screens")
def get_screens():
    rows = fetch_all("""SELECT sc.id, sc.name, sc.label, sc.features,
        (SELECT COUNT(*) FROM seats s WHERE s.screen_id=sc.id) AS capacity
        FROM screens sc WHERE sc.is_active=1 ORDER BY sc.name""")
    return jsonify([{"id": r["id"], "name": r["name"], "label": r["label"],
                     "capacity": int(r["capacity"]), "features": [x for x in r["features"].split(",") if x]}
                    for r in rows])


@app.get("/api/shows")
def get_shows():
    where = ["sh.show_date >= CURDATE()", "m.is_active=1", "sc.is_active=1"]
    params: list[Any] = []
    for arg, column in (("movie_id", "sh.movie_id"), ("screen_id", "sh.screen_id")):
        value = request.args.get(arg)
        if value:
            where.append(f"{column}=%s")
            params.append(value)
    if request.args.get("screen"):
        where.append("sc.name=%s")
        params.append(request.args["screen"])
    if request.args.get("time"):
        where.append("TIME_FORMAT(sh.show_time,'%H:%i')=%s")
        params.append(request.args["time"][:5])
    if request.args.get("date"):
        where.append("sh.show_date=%s")
        params.append(request.args["date"])
    rows = fetch_all(f"""SELECT sh.id, sh.movie_id, m.title AS movie_title, sh.screen_id,
        sc.name AS screen, sc.label AS screen_label, sh.show_date, sh.show_time, sh.base_price,
        (SELECT COUNT(*) FROM seats s WHERE s.screen_id=sh.screen_id) AS capacity
        FROM shows sh JOIN movies m ON m.id=sh.movie_id JOIN screens sc ON sc.id=sh.screen_id
        WHERE {' AND '.join(where)} ORDER BY sh.show_date, sh.show_time, sc.name""", tuple(params))
    return jsonify([{
        "id": r["id"], "movie_id": r["movie_id"], "movie_title": r["movie_title"],
        "screen_id": r["screen_id"], "screen": r["screen"], "screen_label": r["screen_label"],
        "date": iso_date(r["show_date"]), "show_date": iso_date(r["show_date"]),
        "time": time_text(r["show_time"]), "capacity": int(r["capacity"]), "base_price": int(r["base_price"])
    } for r in rows])


@app.post("/api/admin/shows")
def add_show():
    """Create a screening slot for a newly added movie (demo/admin API)."""
    payload = request.get_json(silent=True) or {}
    movie_id = str(payload.get("movie_id", "")).strip()
    screen_id = str(payload.get("screen_id", "")).strip()
    show_date = str(payload.get("date", "")).strip()
    show_time = str(payload.get("time", "")).strip()
    if not all([movie_id, screen_id, show_date, show_time]):
        return api_error("movie_id, screen_id, date (YYYY-MM-DD) and time (HH:MM) are required.")
    try:
        parsed_date = date.fromisoformat(show_date)
        parsed_time = time.fromisoformat(show_time)
    except ValueError:
        return api_error("Use date YYYY-MM-DD and time HH:MM.")
    if parsed_date < date.today():
        return api_error("A screening date cannot be in the past.")
    connection = connect_db()
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT base_price FROM movies WHERE id=%s AND is_active=1", (movie_id,))
        movie = cursor.fetchone()
        cursor.execute("SELECT id FROM screens WHERE id=%s AND is_active=1", (screen_id,))
        screen = cursor.fetchone()
        if not movie:
            return api_error("Movie not found in the catalogue.", 404)
        if not screen:
            return api_error("Screen not found.", 404)
        show_id = f"show-{movie_id}-{screen_id}-{parsed_date:%Y%m%d}-{parsed_time.strftime('%H%M')}"
        cursor.execute("INSERT INTO shows (id,movie_id,screen_id,show_date,show_time,base_price) VALUES (%s,%s,%s,%s,%s,%s)",
                       (show_id, movie_id, screen_id, parsed_date, parsed_time, int(payload.get("base_price", movie["base_price"]))))
        cursor.execute("INSERT INTO show_seats (show_id,screen_id,seat_id,status) SELECT %s,screen_id,seat_id,'available' FROM seats WHERE screen_id=%s", (show_id, screen_id))
        connection.commit()
        return jsonify({"id": show_id, "movie_id": movie_id, "screen_id": screen_id, "date": show_date, "time": parsed_time.strftime("%H:%M")}), 201
    except IntegrityError:
        connection.rollback()
        return api_error("That screen already has a show at this date and time, or the show ID already exists.", 409)
    finally:
        connection.close()


@app.get("/api/shows/<show_id>/seats")
def get_show_seats(show_id: str):
    show = get_show(show_id)
    if not show:
        return api_error("Screening not found.", 404)
    rows = fetch_all("""SELECT ss.seat_id, s.row_label, s.seat_number, s.zone, s.seat_type,
        s.is_aisle, s.is_center, ss.status, sh.base_price
        FROM show_seats ss JOIN seats s ON s.screen_id=ss.screen_id AND s.seat_id=ss.seat_id
        JOIN shows sh ON sh.id=ss.show_id
        WHERE ss.show_id=%s ORDER BY s.row_label, s.seat_number""", (show_id,))
    result = []
    for row in rows:
        zone = row["zone"]
        result.append({
            "id": row["seat_id"], "row": row["row_label"], "number": int(row["seat_number"]),
            "zone": zone, "zone_label": {"front": "Front row", "center": "Gold centre zone", "recliner": "Recliner zone"}[zone],
            "seat_type": row["seat_type"], "status": row["status"], "price_class": zone,
            "standard_price": seat_price(row["base_price"], zone, "classic"),
            "ac_price": seat_price(row["base_price"], zone, "ac"),
            "is_aisle": bool(row["is_aisle"]), "is_center": bool(row["is_center"]),
        })
    return jsonify({"show": show, "seats": result})


@app.get("/api/bookings")
def get_bookings():
    rows = fetch_all("""SELECT b.id, b.booking_ref, b.status, b.experience, b.preference, b.total_price,
        b.created_at, b.cancelled_at, sh.id AS show_id, sh.show_date, sh.show_time,
        sc.name AS screen, m.id AS movie_id, m.title,
        GROUP_CONCAT(bs.seat_id ORDER BY bs.seat_id SEPARATOR ',') AS seats_csv
        FROM bookings b JOIN shows sh ON sh.id=b.show_id JOIN screens sc ON sc.id=sh.screen_id
        JOIN movies m ON m.id=sh.movie_id LEFT JOIN booking_seats bs ON bs.booking_id=b.id
        GROUP BY b.id, b.booking_ref, b.status, b.experience, b.preference, b.total_price,
        b.created_at, b.cancelled_at, sh.id, sh.show_date, sh.show_time, sc.name, m.id, m.title
        ORDER BY b.created_at DESC""")
    return jsonify([{
        "id": r["id"], "ref": r["booking_ref"], "status": r["status"],
        "experience": "Air-conditioned" if r["experience"] == "ac" else "Classic non-AC",
        "experience_code": r["experience"], "preference": r["preference"],
        "price": int(r["total_price"]), "created_at": iso_date(r["created_at"]),
        "cancelled_at": iso_date(r["cancelled_at"]) if r["cancelled_at"] else None,
        "show_id": r["show_id"], "show_date": iso_date(r["show_date"]),
        "showtime": time_text(r["show_time"]), "screen": r["screen"],
        "movie_id": r["movie_id"], "title": r["title"],
        "seats": (r["seats_csv"] or "").split(",") if r["seats_csv"] else [],
    } for r in rows])


@app.post("/api/bookings")
def create_booking():
    payload = request.get_json(silent=True) or {}
    show_id = str(payload.get("show_id", ""))
    seats = payload.get("seats", [])
    experience = payload.get("experience", "ac")
    preference = payload.get("preference", "all")
    if not show_id:
        return api_error("Please choose a screening.")
    if not isinstance(seats, list) or not seats:
        return api_error("Choose at least one seat.")
    if len(seats) > 8:
        return api_error("You can book up to 8 seats per booking.")
    if any(not isinstance(seat, str) for seat in seats) or len(set(seats)) != len(seats):
        return api_error("Seat labels must be valid and unique.")
    if experience not in ("ac", "classic"):
        return api_error("Choose Air-conditioned or Classic non-AC.")
    if preference not in ("all", "center", "aisle", "recliner"):
        return api_error("Choose a valid seating preference.")

    connection = connect_db()
    try:
        connection.start_transaction()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("""SELECT sh.id, sh.base_price, m.title, m.id AS movie_id,
            sc.name AS screen, sc.id AS screen_id, sh.show_time, sh.show_date
            FROM shows sh JOIN movies m ON m.id=sh.movie_id JOIN screens sc ON sc.id=sh.screen_id
            WHERE sh.id=%s AND sh.show_date >= CURDATE() AND m.is_active=1""", (show_id,))
        show = cursor.fetchone()
        if not show:
            connection.rollback()
            return api_error("Please choose a valid upcoming screening.", 404)
        placeholders = ",".join(["%s"] * len(seats))
        cursor.execute(f"""SELECT ss.seat_id, ss.status, s.zone FROM show_seats ss
            JOIN seats s ON s.screen_id=ss.screen_id AND s.seat_id=ss.seat_id
            WHERE ss.show_id=%s AND ss.seat_id IN ({placeholders}) FOR UPDATE""", (show_id, *seats))
        selected = cursor.fetchall()
        if len(selected) != len(seats) or any(row["status"] != "available" for row in selected):
            connection.rollback()
            return jsonify({"error": "Some seats have just become unavailable. Please choose again.",
                            "conflicting_seats": [row["seat_id"] for row in selected if row["status"] != "available"]}), 409
        prices = {row["seat_id"]: seat_price(show["base_price"], row["zone"], experience) for row in selected}
        total = sum(prices.values())
        ref = "CV-" + secrets.token_hex(4).upper()
        cursor.execute("INSERT INTO bookings (booking_ref,show_id,experience,preference,status,total_price) VALUES (%s,%s,%s,%s,'Confirmed',%s)",
                       (ref, show_id, experience, preference, total))
        booking_id = cursor.lastrowid
        cursor.executemany("INSERT INTO booking_seats (booking_id,show_id,seat_id,seat_price,status) VALUES (%s,%s,%s,%s,'Active')",
                           [(booking_id, show_id, seat, prices[seat]) for seat in seats])
        connection.commit()
        return jsonify({
            "ref": ref, "movie_id": show["movie_id"], "title": show["title"], "show_id": show_id,
            "showtime": time_text(show["show_time"]), "show_date": iso_date(show["show_date"]),
            "screen": show["screen"], "screen_id": show["screen_id"], "seats": sorted(seats),
            "experience": "Air-conditioned" if experience == "ac" else "Classic non-AC",
            "experience_code": experience, "preference": preference, "status": "Confirmed",
            "price": total, "created_at": datetime.now().isoformat(timespec="seconds"),
        }), 201
    except IntegrityError:
        connection.rollback()
        return jsonify({"error": "Some seats have just become unavailable. Please choose again.", "conflicting_seats": seats}), 409
    except MySQLError:
        connection.rollback()
        raise
    finally:
        connection.close()


@app.post("/api/bookings/<ref>/cancel")
def cancel_booking(ref: str):
    connection = connect_db()
    try:
        cursor = connection.cursor(dictionary=True)
        connection.start_transaction()
        cursor.execute("SELECT id,status FROM bookings WHERE booking_ref=%s FOR UPDATE", (ref,))
        booking = cursor.fetchone()
        if not booking:
            connection.rollback()
            return api_error("Booking reference not found.", 404)
        if booking["status"] != "Confirmed":
            connection.rollback()
            return api_error("This booking is already cancelled.", 409)
        cursor.execute("UPDATE bookings SET status='Cancelled', cancelled_at=NOW() WHERE id=%s", (booking["id"],))
        # trg_booking_cancel_release_seats releases associated seats automatically.
        connection.commit()
        return jsonify({"ref": ref, "status": "Cancelled"})
    except MySQLError:
        connection.rollback()
        raise
    finally:
        connection.close()


@app.get("/api/insights")
def get_insights():
    connection = connect_db()
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.callproc("sp_show_occupancy")
        show_occupancy = []
        for result in cursor.stored_results():
            show_occupancy = result.fetchall()
        cursor.execute("SELECT COUNT(*) AS total FROM movies WHERE is_active=1")
        movie_count = cursor.fetchone()["total"]
        cursor.execute("SELECT COUNT(*) AS total FROM screens WHERE is_active=1")
        screen_count = cursor.fetchone()["total"]
        cursor.execute("SELECT COUNT(*) AS total FROM shows WHERE show_date >= CURDATE()")
        show_count = cursor.fetchone()["total"]
        cursor.execute("SELECT COUNT(*) AS total FROM bookings WHERE status='Confirmed'")
        confirmed_count = cursor.fetchone()["total"]
        cursor.execute("SELECT COUNT(*) AS total FROM bookings")
        total_bookings = cursor.fetchone()["total"]
        cursor.execute("""SELECT b.booking_ref AS ref, m.title, TIME_FORMAT(sh.show_time,'%H:%i') AS showtime,
            sc.name AS screen, b.status, b.total_price AS price, b.created_at,
            GROUP_CONCAT(bs.seat_id ORDER BY bs.seat_id SEPARATOR ',') AS seats_csv
            FROM bookings b JOIN shows sh ON sh.id=b.show_id JOIN movies m ON m.id=sh.movie_id
            JOIN screens sc ON sc.id=sh.screen_id LEFT JOIN booking_seats bs ON bs.booking_id=b.id
            GROUP BY b.id,b.booking_ref,m.title,sh.show_time,sc.name,b.status,b.total_price,b.created_at
            ORDER BY b.created_at DESC LIMIT 6""")
        recent_rows = cursor.fetchall()
        total_capacity = sum(int(r["capacity"] or 0) for r in show_occupancy if r["show_date"] >= date.today())
        total_booked = sum(int(r["booked_seats"] or 0) for r in show_occupancy if r["show_date"] >= date.today())
        by_movie: dict[str, list[float]] = {}
        for row in show_occupancy:
            if row["show_date"] >= date.today():
                by_movie.setdefault(row["movie_id"], []).append(float(row["occupancy_percent"] or 0))
        movie_titles = {r["movie_id"]: r["title"] for r in show_occupancy}
        occupancy_by_movie = [{"movie_id": mid, "title": movie_titles.get(mid, mid), "value": round(sum(vals)/len(vals))}
                               for mid, vals in by_movie.items()]
        occupancy_by_movie.sort(key=lambda r: r["value"], reverse=True)
        recent = [{"ref": r["ref"], "title": r["title"], "showtime": r["showtime"], "screen": r["screen"],
                   "status": r["status"], "price": int(r["price"]), "created_at": iso_date(r["created_at"]),
                   "seats": (r["seats_csv"] or "").split(",") if r["seats_csv"] else []} for r in recent_rows]
        return jsonify({
            "movie_count": int(movie_count), "screen_count": int(screen_count), "show_count": int(show_count),
            "confirmed_bookings": int(confirmed_count), "total_bookings": int(total_bookings),
            "occupancy_percent": round(total_booked / total_capacity * 100) if total_capacity else 0,
            "occupancy_by_movie": occupancy_by_movie, "recent_bookings": recent, "storage": "MySQL",
        })
    finally:
        connection.close()


@app.errorhandler(MySQLError)
def database_error(error):
    app.logger.exception("MySQL request failed")
    return jsonify({"error": "MySQL could not complete the request. Check your database connection and schema setup."}), 503


@app.errorhandler(404)
def not_found(error):
    if request.path.startswith("/api/"):
        return api_error("API endpoint not found.", 404)
    return error


if __name__ == "__main__":
    print("\nCineVault MySQL API is starting...")
    print("Open http://127.0.0.1:5000 in your browser.\n")
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=True)
