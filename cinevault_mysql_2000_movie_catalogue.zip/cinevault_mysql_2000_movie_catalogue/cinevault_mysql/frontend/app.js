/* CineVault frontend connected to the local Flask API. */
const API = '/api';
let movies = [];
let screens = [];
let moviePage = 0;
const moviePageSize = 24;
const movieCache = new Map();
let currentShows = [];
let currentShowId = null;
let selectedMovie = null;
let selectedSeats = [];
let seatData = [];
let selectedExperience = 'ac';
let seatPreference = 'all';
let bookings = [];
let toastTimer;
const $ = id => document.getElementById(id);

async function api(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(data.error || `Request failed (${response.status})`);
    error.status = response.status;
    error.data = data;
    throw error;
  }
  return data;
}
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
}
function toast(message) {
  const el = $('toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 3000);
}
function movieCard(movie) {
  const yearLabel = movie.year ? String(movie.year) : 'Year not listed';
  const ratingLabel = movie.rating && Number(movie.rating) > 0 ? `★ ${escapeHtml(movie.rating)}` : 'Rating not supplied';
  const posterRating = movie.rating && Number(movie.rating) > 0 ? `<span class="poster-rating">★ ${escapeHtml(movie.rating)}</span>` : '';
  const durationLabel = movie.duration && movie.duration !== 'Not listed' ? movie.duration : 'Runtime not listed';
  return `<article class="movie-card"><div class="poster" style="--poster-bg:${movie.bg};--orb:${movie.orb};--orb-light:${movie.orbLight};--poster-accent:${movie.accent};--poster-image:url('${movie.image}')"><div class="poster-art"><div class="poster-orb"></div><div class="poster-shape"></div><div class="poster-lines"></div></div><span class="poster-badge">${escapeHtml(movie.tag)}</span>${posterRating}<div class="poster-title"><small>${movie.featured ? 'CINEVAULT PICK' : 'MOVIE CATALOGUE'}</small><strong>${escapeHtml(movie.title)}</strong><span>${escapeHtml(movie.genre.toUpperCase())} · ${escapeHtml(yearLabel)}</span></div></div><div class="movie-info"><div class="movie-topline"><div><h3>${escapeHtml(movie.title)}</h3><div class="movie-meta">${escapeHtml(yearLabel)} &nbsp;·&nbsp; ${escapeHtml(durationLabel)} &nbsp;·&nbsp; ${ratingLabel}</div></div><span class="movie-genre">${escapeHtml(movie.genre)}</span></div><p class="movie-desc">${escapeHtml(movie.desc)}</p><div class="movie-bottom"><div class="movie-price"><small>DEMO TICKET FROM</small><strong>₹${movie.price}</strong><small>${escapeHtml(movie.language)} · ${movie.featured ? 'Curated data' : 'Catalogue entry'}</small></div><button class="book-button" data-book="${escapeHtml(movie.id)}">Choose seats ↗</button></div></div></article>`;
}
async function renderMovies() {
  try {
    const query = encodeURIComponent(($('movieSearch')?.value || '').trim());
    const genre = encodeURIComponent($('genreFilter')?.value || 'all');
    const language = encodeURIComponent($('languageFilter')?.value || 'all');
    const sort = encodeURIComponent($('sortFilter')?.value || 'featured');
    const offset = moviePage * moviePageSize;
    const result = await api(`/movies?q=${query}&genre=${genre}&language=${language}&sort=${sort}&limit=${moviePageSize}&offset=${offset}`);
    const list = Array.isArray(result) ? result : (result.items || []);
    const total = Array.isArray(result) ? list.length : Number(result.total || 0);
    list.forEach(movie => movieCache.set(movie.id, movie));
    $('allMovies').innerHTML = list.map(movieCard).join('');
    $('emptyMovies').classList.toggle('hidden', list.length > 0);
    $('movieResultsSummary').textContent = total ? `Showing ${offset + 1}–${Math.min(offset + list.length, total)} of ${total.toLocaleString()} catalogue titles` : 'No catalogue titles match those filters.';
    const pageCount = Math.max(1, Math.ceil(total / moviePageSize));
    if (moviePage >= pageCount) moviePage = Math.max(0, pageCount - 1);
    $('moviePagination').innerHTML = total > moviePageSize ? `<button class="page-button" data-movie-page="prev" ${moviePage === 0 ? 'disabled' : ''}>← Previous</button><span>Page ${moviePage + 1} of ${pageCount}</span><button class="page-button" data-movie-page="next" ${moviePage + 1 >= pageCount ? 'disabled' : ''}>Next →</button>` : '';
  } catch (error) { toast(`Couldn't load movies: ${error.message}`); }
}
function renderFeatured() {
  const featured = $('featuredMovies');
  featured.innerHTML = movies.slice(0, 3).map(movieCard).join('');
}
function navigate(view) {
  document.querySelectorAll('.view').forEach(v => v.classList.toggle('active', v.id === `view-${view}`));
  document.querySelectorAll('.nav-link').forEach(b => b.classList.toggle('active', b.dataset.view === view));
  document.querySelector('.main-nav')?.classList.remove('open');
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (view === 'movies') renderMovies();
  if (view === 'bookings') renderBookings();
  if (view === 'admin') renderAdmin();
}
function formatTime(time) {
  const [h, m] = String(time).split(':').map(Number);
  return `${h % 12 || 12}:${String(m).padStart(2, '0')} ${h >= 12 ? 'PM' : 'AM'}`;
}
function formatDate(dateValue) {
  if (!dateValue) return 'Choose date';
  const date = new Date(`${dateValue}T12:00:00`);
  return date.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
}
function setSelectOptions(select, options, valueKey, labelFn) {
  const previous = select.value;
  select.innerHTML = options.map(item => `<option value="${escapeHtml(item[valueKey])}">${escapeHtml(labelFn(item))}</option>`).join('');
  if (options.some(item => String(item[valueKey]) === previous)) select.value = previous;
}
async function openBooking(movieId) {
  selectedMovie = movieCache.get(movieId) || movies.find(m => m.id === movieId);
  if (!selectedMovie) { toast('That movie could not be found.'); return; }
  selectedSeats = [];
  selectedExperience = 'ac';
  seatPreference = 'all';
  currentShowId = null;
  $('modalMovieName').textContent = `${selectedMovie.title} · ${selectedMovie.duration}`;
  $('modalTitle').innerHTML = 'Choose your <em>seats.</em>';
  try {
    currentShows = await api(`/shows?movie_id=${encodeURIComponent(movieId)}`);
    if (!currentShows.length) { toast('No upcoming screenings are scheduled for this movie yet.'); return; }
    const dates = [...new Map(currentShows.map(s => [s.show_date || s.date, {date:s.show_date || s.date}])).values()];
    setSelectOptions($('showDateSelect'), dates, 'date', d => formatDate(d.date));
    updateShowOptionsForDate();
    document.querySelectorAll('[data-experience]').forEach(b => b.classList.toggle('active', b.dataset.experience === selectedExperience));
    document.querySelectorAll('[data-preference]').forEach(b => b.classList.toggle('active', b.dataset.preference === seatPreference));
    await refreshSeatMap();
    $('bookingModal').classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  } catch (error) { toast(`Couldn't open screening: ${error.message}`); }
}
function closeBooking() { $('bookingModal').classList.add('hidden'); document.body.style.overflow = ''; }
function updateShowOptionsForDate() {
  const selectedDate = $('showDateSelect').value;
  const dayShows = currentShows.filter(show => (show.show_date || show.date) === selectedDate);
  const times = [...new Map(dayShows.map(s => [s.time, {time:s.time}])).values()];
  const availableScreens = [...new Map(dayShows.map(s => [s.screen, {name:s.screen, label:s.screen_label || s.screen}])).values()];
  setSelectOptions($('showtimeSelect'), times, 'time', s => formatTime(s.time));
  setSelectOptions($('screenSelect'), availableScreens, 'name', s => `${s.name} · ${s.label}`);
}
function findCurrentShow() {
  const selectedDate = $('showDateSelect').value;
  return currentShows.find(show => (show.show_date || show.date) === selectedDate && show.time === $('showtimeSelect').value && show.screen === $('screenSelect').value);
}
async function refreshSeatMap() {
  const show = findCurrentShow();
  if (!show) { toast('No screening exists for that time and screen.'); return; }
  currentShowId = show.id;
  selectedSeats = [];
  $('seatMap').innerHTML = '<p class="seat-loading">Checking seat availability…</p>';
  try {
    const response = await api(`/shows/${encodeURIComponent(currentShowId)}/seats`);
    seatData = response.seats;
    renderSeatMap();
    updateSeatSummary();
  } catch (error) { $('seatMap').innerHTML = ''; toast(`Couldn't load seats: ${error.message}`); }
}
function renderSeatMap() {
  const rows = ['A', 'B', 'C', 'D', 'E', 'F'];
  $('seatMap').innerHTML = rows.map(row => {
    const seats = seatData.filter(seat => seat.row === row).map(seat => {
      const occupied = seat.status === 'booked';
      const selected = selectedSeats.includes(seat.id);
      const recommended = seatPreference === 'center' ? seat.is_center : seatPreference === 'aisle' ? seat.is_aisle : seatPreference === 'recliner' ? seat.zone === 'recliner' : false;
      const zoneClass = `${seat.zone}-seat`;
      const title = `${seat.id} · ${seat.zone_label} · ${occupied ? 'Taken' : 'Available'}`;
      return `<button type="button" class="seat ${zoneClass} ${occupied ? 'occupied' : ''} ${selected ? 'selected' : ''} ${recommended && !occupied ? 'recommended' : ''}" data-seat="${seat.id}" ${occupied ? 'disabled' : ''} aria-label="${escapeHtml(title)}" title="${escapeHtml(title)}">${seat.number}</button>`;
    }).join('');
    return `<div class="seat-row-group ${row < 'C' ? 'front-row-group' : row < 'E' ? 'center-row-group' : 'recliner-row-group'}"><span class="seat-row-label">${row}</span><div class="seat-row-seats">${seats}</div><span class="seat-row-label right-row-label">${row}</span></div>`;
  }).join('');
}
function getSeat(seatId) { return seatData.find(seat => seat.id === seatId); }
function seatFare(seatId) {
  const seat = getSeat(seatId);
  if (!seat) return 0;
  return selectedExperience === 'ac' ? seat.ac_price : seat.standard_price;
}
function updateExperience(experience) {
  selectedExperience = experience;
  document.querySelectorAll('[data-experience]').forEach(b => b.classList.toggle('active', b.dataset.experience === experience));
  updateSeatSummary();
}
function updateSeatPreference(preference) {
  seatPreference = preference;
  document.querySelectorAll('[data-preference]').forEach(b => b.classList.toggle('active', b.dataset.preference === preference));
  renderSeatMap();
}
function updateSeatSummary() {
  $('selectedSeatsLabel').textContent = selectedSeats.length ? [...selectedSeats].sort().join(', ') : 'Choose your seats';
  const total = selectedSeats.reduce((sum, seat) => sum + seatFare(seat), 0);
  $('totalPrice').textContent = `₹${total}`;
  $('seatSummaryDetail').textContent = selectedSeats.length ? `${selectedExperience === 'ac' ? 'Air-conditioned' : 'Classic non-AC'} · ${selectedSeats.length} seat${selectedSeats.length === 1 ? '' : 's'} · zone pricing included` : 'Pick seats to see your cinema plan';
  $('confirmBooking').disabled = selectedSeats.length === 0;
  $('confirmBooking').style.opacity = selectedSeats.length === 0 ? '.5' : '1';
}
async function confirmBooking() {
  if (!currentShowId || !selectedSeats.length) { toast('Choose at least one available seat first.'); return; }
  $('confirmBooking').disabled = true;
  try {
    const booking = await api('/bookings', {
      method: 'POST',
      body: JSON.stringify({ show_id: currentShowId, seats: selectedSeats, experience: selectedExperience, preference: seatPreference })
    });
    closeBooking();
    toast(`You're all set! Booking ${booking.ref} confirmed.`);
    await Promise.all([renderBookings(), renderAdmin(), updateBookingCount()]);
    navigate('bookings');
  } catch (error) {
    if (error.status === 409) {
      toast(`${error.message} Refreshing the seat map.`);
      await refreshSeatMap();
    } else toast(error.message);
  } finally { $('confirmBooking').disabled = selectedSeats.length === 0; }
}
async function renderBookings() {
  try {
    bookings = await api('/bookings');
    const list = $('bookingList');
    if (!bookings.length) {
      list.innerHTML = '';
      $('emptyBookings').classList.remove('hidden');
      updateBookingCountFrom(bookings);
      return;
    }
    $('emptyBookings').classList.add('hidden');
    list.innerHTML = bookings.map(b => `<article class="booking-ticket"><div class="ticket-main"><div class="ticket-symbol">▤</div><div><h3>${escapeHtml(b.title)}</h3><p>${formatDate(b.show_date)} · ${formatTime(b.showtime)} · ${escapeHtml(b.screen)}${b.experience ? ' · ' + escapeHtml(b.experience) : ''} · Seats ${b.seats.map(escapeHtml).join(', ')}</p><div class="ticket-reference">${escapeHtml(b.ref)} · ${escapeHtml(b.status)}</div></div></div><div class="ticket-side"><strong class="ticket-price">₹${b.price}</strong>${b.status === 'Confirmed' ? `<button class="cancel-button" data-cancel="${escapeHtml(b.ref)}">Cancel ticket</button>` : '<span class="status-chip cancelled">Cancelled</span>'}</div></article>`).join('');
    updateBookingCountFrom(bookings);
  } catch (error) { toast(`Couldn't load your tickets: ${error.message}`); }
}
function updateBookingCountFrom(list) {
  $('bookingCount').textContent = list.filter(b => b.status === 'Confirmed').length;
}
async function updateBookingCount() {
  try { const list = await api('/bookings'); updateBookingCountFrom(list); }
  catch { $('bookingCount').textContent = '—'; }
}
async function cancelBooking(ref) {
  const booking = bookings.find(b => b.ref === ref);
  if (!booking || booking.status !== 'Confirmed') return;
  if (!confirm(`Cancel booking ${ref} for ${booking.title}?`)) return;
  try {
    await api(`/bookings/${encodeURIComponent(ref)}/cancel`, { method: 'POST', body: '{}' });
    toast(`Booking ${ref} cancelled. Its seats are available again.`);
    await Promise.all([renderBookings(), renderAdmin()]);
  } catch (error) { toast(error.message); }
}
async function renderAdmin() {
  try {
    const stats = await api('/insights');
    $('statMovies').textContent = stats.movie_count;
    $('statBookings').textContent = stats.confirmed_bookings;
    const statCards = document.querySelectorAll('.stats-grid .stat-card');
    if (statCards[2]) {
      statCards[2].querySelector('strong').textContent = `${stats.occupancy_percent}%`;
      statCards[2].querySelector('.stat-foot').textContent = 'From current screening inventory';
    }
    if (statCards[3]) {
      statCards[3].querySelector('strong').textContent = 'API ON';
      statCards[3].querySelector('.stat-foot').textContent = 'Local backend running';
    }
    const occupancy = stats.occupancy_by_movie.slice(0, 4);
    $('occupancyList').innerHTML = occupancy.map(s => `<div class="occupancy-row"><strong>${escapeHtml(s.title)}</strong><div class="occupancy-track"><div class="occupancy-fill" style="width:${s.value}%"></div></div><span>${s.value}%</span></div>`).join('');
    const banner = document.querySelector('.demo-banner');
    if (banner) banner.innerHTML = '<span>✦</span><div><strong>Python API connected</strong><small>Movie catalogue, showtimes, seat availability, bookings and insights are served by the local backend. MySQL triggers come in the next phase.</small></div>';
    const panelPill = document.querySelector('.occupancy-panel .demo-pill');
    if (panelPill) panelPill.textContent = 'LIVE DEMO API';
    const note = document.querySelector('.occupancy-panel .panel-note');
    if (note) note.textContent = 'Occupancy is calculated from the backend demo inventory and confirmed bookings. MySQL stored procedures will replace this calculation in the database phase.';
    const tablePill = document.querySelector('.table-panel .demo-pill');
    if (tablePill) tablePill.textContent = 'BACKEND RECORDS';
    const recent = stats.recent_bookings || [];
    $('adminBookings').innerHTML = recent.length ? recent.map(b => `<tr><td>${escapeHtml(b.ref)}</td><td>${escapeHtml(b.title)}</td><td>${formatTime(b.showtime)}</td><td>${b.seats.map(escapeHtml).join(', ')}</td><td><span class="status-chip ${b.status === 'Cancelled' ? 'cancelled' : ''}">${escapeHtml(b.status)}</span></td></tr>`).join('') : '<tr><td colspan="5" class="table-empty">No bookings yet. Book a ticket to see a record here.</td></tr>';
  } catch (error) { toast(`Couldn't load studio insights: ${error.message}`); }
}
async function init() {
  try {
    const health = await api('/health');
    const initialCatalogue = await api('/movies?limit=40&sort=featured');
    movies = initialCatalogue.items || [];
    movies.forEach(movie => movieCache.set(movie.id, movie));
    screens = await api('/screens');
    const genreSelect = $('genreFilter');
    const existingGenre = genreSelect.value || 'all';
    const genres = [...new Set([...movies.map(movie => movie.genre), 'Unclassified'])].sort((a,b) => a.localeCompare(b));
    genreSelect.innerHTML = '<option value="all">All genres</option>' + genres.map(genre => `<option value="${escapeHtml(genre)}">${escapeHtml(genre)}</option>`).join('');
    genreSelect.value = genres.includes(existingGenre) ? existingGenre : 'all';
    renderFeatured();
    await Promise.all([renderMovies(), renderBookings(), renderAdmin()]);
    document.body.dataset.apiStatus = health.status;
  } catch (error) {
    toast('CineVault API is not running. Start it with: python app.py');
    console.error('CineVault API connection failed:', error);
  }
}

document.addEventListener('click', async event => {
  const pageControl = event.target.closest('[data-movie-page]');
  if (pageControl && !pageControl.disabled) { moviePage = pageControl.dataset.moviePage === 'next' ? moviePage + 1 : Math.max(0, moviePage - 1); await renderMovies(); return; }
  const nav = event.target.closest('[data-view]');
  if (nav) { event.preventDefault(); navigate(nav.dataset.view); return; }
  const book = event.target.closest('[data-book]');
  if (book) { await openBooking(book.dataset.book); return; }
  const seatButton = event.target.closest('[data-seat]');
  if (seatButton && !seatButton.disabled) {
    const value = seatButton.dataset.seat;
    if (selectedSeats.includes(value)) selectedSeats = selectedSeats.filter(s => s !== value);
    else if (selectedSeats.length >= 8) { toast('For this demo, choose up to 8 seats per booking.'); return; }
    else selectedSeats.push(value);
    renderSeatMap(); updateSeatSummary(); return;
  }
  const cancel = event.target.closest('[data-cancel]');
  if (cancel) await cancelBooking(cancel.dataset.cancel);
});
document.querySelectorAll('[data-experience]').forEach(button => button.addEventListener('click', () => updateExperience(button.dataset.experience)));
document.querySelectorAll('[data-preference]').forEach(button => button.addEventListener('click', () => updateSeatPreference(button.dataset.preference)));
$('movieSearch').addEventListener('input', () => { moviePage = 0; renderMovies(); });
$('genreFilter').addEventListener('change', () => { moviePage = 0; renderMovies(); });
$('languageFilter').addEventListener('change', () => { moviePage = 0; renderMovies(); });
$('sortFilter').addEventListener('change', () => { moviePage = 0; renderMovies(); });
$('showDateSelect').addEventListener('change', () => { updateShowOptionsForDate(); refreshSeatMap(); });
$('showtimeSelect').addEventListener('change', refreshSeatMap);
$('screenSelect').addEventListener('change', refreshSeatMap);
$('closeModal').addEventListener('click', closeBooking);
$('bookingModal').addEventListener('click', event => { if (event.target === $('bookingModal')) closeBooking(); });
$('confirmBooking').addEventListener('click', confirmBooking);
$('searchToggle').addEventListener('click', () => { navigate('movies'); setTimeout(() => $('movieSearch').focus(), 200); });
$('profileButton').addEventListener('click', () => toast('Welcome to CineVault — guest demo mode. No account is needed for this local prototype.'));
$('heroTrailer').addEventListener('click', () => toast('The lights are dimming… choose a movie below to start your cinema night.'));
$('menuToggle').addEventListener('click', () => document.querySelector('.main-nav').classList.toggle('open'));
document.addEventListener('keydown', event => { if (event.key === 'Escape' && !$('bookingModal').classList.contains('hidden')) closeBooking(); });
init();
