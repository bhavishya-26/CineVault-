
const fs = require("fs");
const path = require("path");
const mysql = require("mysql2/promise");
const { parse } = require("csv-parse/sync");
require("dotenv").config();

const csvPath = path.join(
  __dirname,
  "database",
  "complete_catalogue.csv"
);

const palettes = [
  {
    bg: "linear-gradient(135deg, #10131B, #202A44)",
    orb: "#6C5CE7",
    orb_light: "#A29BFE",
    accent: "#F5A623"
  },
  {
    bg: "linear-gradient(135deg, #1C1018, #48243B)",
    orb: "#E84393",
    orb_light: "#FD79A8",
    accent: "#FDCB6E"
  },
  {
    bg: "linear-gradient(135deg, #101D20, #174D4A)",
    orb: "#00B894",
    orb_light: "#55EFC4",
    accent: "#FFEAA7"
  },
  {
    bg: "linear-gradient(135deg, #201510, #56351E)",
    orb: "#E17055",
    orb_light: "#FAB1A0",
    accent: "#FDCB6E"
  }
];

async function importMovies() {
  let connection;

  try {
    if (!fs.existsSync(csvPath)) {
      throw new Error(`CSV file not found: ${csvPath}`);
    }

    const csvText = fs.readFileSync(csvPath, "utf8");

    const movies = parse(csvText, {
      columns: true,
      skip_empty_lines: true,
      bom: true,
      trim: true
    });

    if (movies.length === 0) {
      throw new Error("The CSV contains no movie records.");
    }

    const requiredColumns = [
      "id",
      "title",
      "language",
      "genre",
      "release_year",
      "duration",
      "rating",
      "base_price_inr",
      "tag",
      "description",
      "certificate",
      "featured",
      "image_url"
    ];

    const missingColumns = requiredColumns.filter(
      column => !Object.prototype.hasOwnProperty.call(
        movies[0],
        column
      )
    );

    if (missingColumns.length > 0) {
      throw new Error(
        `Missing CSV columns: ${missingColumns.join(", ")}`
      );
    }

    const seenIds = new Set();

    const rows = movies.map((movie, index) => {
      const id = (movie.id || "").trim();
      const title = (movie.title || "").trim();

      if (!id || !title) {
        throw new Error(
          `Movie record ${index + 2} has no ID or title.`
        );
      }

      if (seenIds.has(id)) {
        throw new Error(`Duplicate movie ID in CSV: ${id}`);
      }

      seenIds.add(id);

      const year = Number(movie.release_year);
      const rating = Number(movie.rating);
      const price = Number(movie.base_price_inr);
if (!Number.isInteger(year) || year < 0 || year > 32767) {
  throw new Error(`Invalid release year for: ${title}`);
}

      if (!Number.isFinite(rating) || rating < 0 || rating > 99.9) {
        throw new Error(`Invalid rating for: ${title}`);
      }

      if (!Number.isInteger(price) || price < 0) {
        throw new Error(`Invalid ticket price for: ${title}`);
      }

      const palette = palettes[index % palettes.length];

      return [
        id,
        title,
        (movie.genre || "Drama").slice(0, 60),
        year,
        (movie.duration || "2h 00m").slice(0, 20),
        rating,
        price,
        (movie.tag || "NOW SHOWING").slice(0, 80),
        (movie.description || "Discover this movie on CineVault.")
          .slice(0, 500),
        palette.bg,
        palette.orb,
        palette.orb_light,
        palette.accent,
        (movie.image_url || "").slice(0, 500),
        (movie.language || "English").slice(0, 50),
        (movie.certificate || "UA").slice(0, 10),
        Number(movie.featured) === 1 ? 1 : 0
      ];
    });

    connection = await mysql.createConnection({
      host: process.env.DB_HOST || "127.0.0.1",
      port: Number(process.env.DB_PORT || 3306),
      user: process.env.DB_USER || "root",
      password: process.env.DB_PASSWORD || "",
      database: process.env.DB_NAME || "cinevault"
    });

    await connection.beginTransaction();

    const sql = `
      INSERT INTO movies (
        id,
        title,
        genre,
        release_year,
        duration,
        rating,
        base_price,
        tag,
        description,
        bg,
        orb,
        orb_light,
        accent,
        image_url,
        language,
        certificate,
        featured
      )
      VALUES ?
      ON DUPLICATE KEY UPDATE
        title = VALUES(title),
        genre = VALUES(genre),
        release_year = VALUES(release_year),
        duration = VALUES(duration),
        rating = VALUES(rating),
        base_price = VALUES(base_price),
        tag = VALUES(tag),
        description = VALUES(description),
        bg = VALUES(bg),
        orb = VALUES(orb),
        orb_light = VALUES(orb_light),
        accent = VALUES(accent),
        image_url = VALUES(image_url),
        language = VALUES(language),
        certificate = VALUES(certificate),
        featured = VALUES(featured)
    `;

    const batchSize = 200;

    for (let start = 0; start < rows.length; start += batchSize) {
      const batch = rows.slice(start, start + batchSize);
      await connection.query(sql, [batch]);

      console.log(
        `Processed ${Math.min(start + batch.length, rows.length)} / ${rows.length} movies`
      );
    }

    await connection.commit();

    const [result] = await connection.query(
      "SELECT COUNT(*) AS total FROM movies"
    );

    console.log("\nSUCCESS! Movie import completed.");
    console.log(`Records processed: ${rows.length}`);
    console.log(`Movies now in database: ${result[0].total}`);
  } catch (error) {
    if (connection) {
      await connection.rollback();
    }

    console.error("\nMOVIE IMPORT FAILED:");
    console.error(error.code || "", error.message);
    console.error("The import transaction was rolled back.");
    process.exitCode = 1;
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

importMovies();
