CREATE DATABASE IF NOT EXISTS cinevault CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE cinevault;

CREATE TABLE IF NOT EXISTS movies (
  id VARCHAR(60) PRIMARY KEY,
  title VARCHAR(180) NOT NULL,
  genre VARCHAR(60) NOT NULL,
  release_year SMALLINT NOT NULL,
  duration VARCHAR(20) NOT NULL,
  rating DECIMAL(3,1) NOT NULL DEFAULT 8.0,
  base_price INT UNSIGNED NOT NULL DEFAULT 220,
  tag VARCHAR(80) NOT NULL DEFAULT 'NOW SHOWING',
  description VARCHAR(500) NOT NULL,
  bg VARCHAR(220) NOT NULL,
  orb VARCHAR(30) NOT NULL,
  orb_light VARCHAR(30) NOT NULL,
  accent VARCHAR(30) NOT NULL,
  image_url VARCHAR(500) NOT NULL,
  language VARCHAR(50) NOT NULL DEFAULT 'English',
  certificate VARCHAR(10) NOT NULL DEFAULT 'UA',
  featured TINYINT(1) NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_movies_title (title),
  INDEX idx_movies_genre (genre),
  INDEX idx_movies_active_featured (is_active, featured)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS screens (
  id VARCHAR(30) PRIMARY KEY,
  name VARCHAR(60) NOT NULL UNIQUE,
  label VARCHAR(100) NOT NULL,
  features VARCHAR(300) NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS seats (
  screen_id VARCHAR(30) NOT NULL,
  seat_id VARCHAR(5) NOT NULL,
  row_label CHAR(1) NOT NULL,
  seat_number TINYINT UNSIGNED NOT NULL,
  zone ENUM('front','center','recliner') NOT NULL,
  seat_type ENUM('Standard','Premium','Recliner') NOT NULL,
  is_aisle TINYINT(1) NOT NULL DEFAULT 0,
  is_center TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (screen_id, seat_id),
  UNIQUE KEY uq_screen_row_number (screen_id, row_label, seat_number),
  CONSTRAINT fk_seats_screen FOREIGN KEY (screen_id) REFERENCES screens(id)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS shows (
  id VARCHAR(140) PRIMARY KEY,
  movie_id VARCHAR(60) NOT NULL,
  screen_id VARCHAR(30) NOT NULL,
  show_date DATE NOT NULL,
  show_time TIME NOT NULL,
  base_price INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_screen_date_time (screen_id, show_date, show_time),
  UNIQUE KEY uq_show_screen (id, screen_id),
  INDEX idx_shows_movie_date (movie_id, show_date),
  CONSTRAINT fk_shows_movie FOREIGN KEY (movie_id) REFERENCES movies(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_shows_screen FOREIGN KEY (screen_id) REFERENCES screens(id)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS show_seats (
  show_id VARCHAR(140) NOT NULL,
  screen_id VARCHAR(30) NOT NULL,
  seat_id VARCHAR(5) NOT NULL,
  status ENUM('available','booked') NOT NULL DEFAULT 'available',
  PRIMARY KEY (show_id, seat_id),
  INDEX idx_show_seats_status (show_id, status),
  CONSTRAINT fk_show_seats_show_screen FOREIGN KEY (show_id, screen_id)
    REFERENCES shows(id, screen_id) ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_show_seats_physical_seat FOREIGN KEY (screen_id, seat_id)
    REFERENCES seats(screen_id, seat_id) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS bookings (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  booking_ref VARCHAR(20) NOT NULL UNIQUE,
  show_id VARCHAR(140) NOT NULL,
  experience ENUM('ac','classic') NOT NULL DEFAULT 'ac',
  preference ENUM('all','center','aisle','recliner') NOT NULL DEFAULT 'all',
  status ENUM('Confirmed','Cancelled') NOT NULL DEFAULT 'Confirmed',
  total_price INT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  cancelled_at DATETIME NULL,
  INDEX idx_bookings_show_status (show_id, status),
  INDEX idx_bookings_created (created_at),
  CONSTRAINT fk_bookings_show FOREIGN KEY (show_id) REFERENCES shows(id)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;


USE cinevault;

CREATE TABLE IF NOT EXISTS booking_seats (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    booking_id BIGINT UNSIGNED NOT NULL,
    show_id VARCHAR(140) NOT NULL,
    seat_id VARCHAR(5) NOT NULL,
    seat_price INT UNSIGNED NOT NULL,
    status ENUM('Active','Released') NOT NULL DEFAULT 'Active',

    active_seat_id VARCHAR(5)
        GENERATED ALWAYS AS (
            CASE WHEN status = 'Active' THEN seat_id ELSE NULL END
        ) STORED,

    PRIMARY KEY (id),
    UNIQUE KEY uq_active_show_seat (show_id, active_seat_id),
    INDEX idx_booking_seats_booking (booking_id),

    CONSTRAINT fk_booking_seats_booking
        FOREIGN KEY (booking_id)
        REFERENCES bookings(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT
) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_0900_ai_ci;

DROP TRIGGER IF EXISTS trg_booking_seats_before_insert;
DROP TRIGGER IF EXISTS trg_booking_seats_after_insert;
DROP TRIGGER IF EXISTS trg_booking_seats_after_release;
DROP TRIGGER IF EXISTS trg_booking_cancel_release_seats;
DROP PROCEDURE IF EXISTS sp_show_occupancy;

DELIMITER $$

CREATE TRIGGER trg_booking_seats_before_insert
BEFORE INSERT ON booking_seats
FOR EACH ROW
BEGIN
    DECLARE seat_state VARCHAR(20);
    DECLARE seat_exists INT DEFAULT 0;

    SELECT COUNT(*), MAX(status)
    INTO seat_exists, seat_state
    FROM show_seats
    WHERE show_id = NEW.show_id
      AND seat_id = NEW.seat_id;

    IF seat_exists = 0 OR seat_state <> 'available' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'Seat is not available for this screening';
    END IF;
END$$

CREATE TRIGGER trg_booking_seats_after_insert
AFTER INSERT ON booking_seats
FOR EACH ROW
BEGIN
    UPDATE show_seats
    SET status = 'booked'
    WHERE show_id = NEW.show_id
      AND seat_id = NEW.seat_id;
END$$

CREATE TRIGGER trg_booking_seats_after_release
AFTER UPDATE ON booking_seats
FOR EACH ROW
BEGIN
    IF OLD.status = 'Active' AND NEW.status = 'Released' THEN
        UPDATE show_seats
        SET status = 'available'
        WHERE show_id = NEW.show_id
          AND seat_id = NEW.seat_id;
    END IF;
END$$

CREATE TRIGGER trg_booking_cancel_release_seats
AFTER UPDATE ON bookings
FOR EACH ROW
BEGIN
    IF OLD.status = 'Confirmed' AND NEW.status = 'Cancelled' THEN
        UPDATE booking_seats
        SET status = 'Released'
        WHERE booking_id = NEW.id
          AND status = 'Active';
    END IF;
END$$

CREATE PROCEDURE sp_show_occupancy()
BEGIN
    SELECT
        sh.id AS show_id,
        m.id AS movie_id,
        m.title,
        sc.name AS screen,
        sh.show_date,
        sh.show_time,
        COUNT(ss.seat_id) AS capacity,
        COALESCE(
            SUM(CASE WHEN ss.status = 'booked' THEN 1 ELSE 0 END),
            0
        ) AS booked_seats,
        ROUND(
            100 * COALESCE(
                SUM(CASE WHEN ss.status = 'booked' THEN 1 ELSE 0 END),
                0
            ) / NULLIF(COUNT(ss.seat_id), 0),
            1
        ) AS occupancy_percent
    FROM shows sh
    JOIN movies m ON m.id = sh.movie_id
    JOIN screens sc ON sc.id = sh.screen_id
    LEFT JOIN show_seats ss ON ss.show_id = sh.id
    GROUP BY
        sh.id, m.id, m.title, sc.name, sh.show_date, sh.show_time
    ORDER BY sh.show_date, sh.show_time, sc.name;
END$$

DELIMITER ;
