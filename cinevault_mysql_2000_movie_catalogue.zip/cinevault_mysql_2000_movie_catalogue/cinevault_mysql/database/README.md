# Database folder

- `schema.sql`: creates the CineVault database, tables, foreign keys, constraints, triggers and occupancy stored procedure in MySQL Workbench.
- `movie_catalogue.csv`: the 1,584 deduplicated title/language entries derived from the supplied 2,000 numbered-title list.
- `source_movie_list.txt`: the original list preserved as supplied.
- `complete_catalogue.csv`: the combined 1,591-record catalogue the seeder will create, including the 40 curated/demo records.
- `movie_catalogue_preview.csv`: the original compact preview of the curated demo titles.
- `catalogue_import_report.txt`: deduplication counts, language assignments and data-quality notes.

Run the root-level `seed_database.py` after `schema.sql` has been executed and `.env` has been configured. It creates the movie rows, screens, seats, the first-week curated schedule, and a 60-day generated catalogue rotation. Generated showtimes and placeholder prices are for the academic demo only, not real-world listings.
