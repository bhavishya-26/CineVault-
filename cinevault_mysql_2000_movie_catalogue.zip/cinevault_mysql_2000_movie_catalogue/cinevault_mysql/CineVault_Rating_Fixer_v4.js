'use strict';

/**
 * CineVault rating-only enrichment v4.
 * Updates only rating=0/NULL rows where TMDB candidate title, original language,
 * release year, and vote threshold all match. Never modifies other metadata or
 * booking tables. Generates a backup and CSV audit report.
 */
require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const mysql = require('mysql2/promise');

const TOKEN = (process.env.TMDB_API_TOKEN || '').trim();
const BASE = 'https://api.themoviedb.org/3';
const EXPECTED = { Telugu: 'te', Hindi: 'hi', English: 'en', Tamil: 'ta', Kannada: 'kn', Malayalam: 'ml', Korean: 'ko' };
const GAP_MS = 180;
const CONCURRENCY = 3;
const MIN_VOTES = 5;
const ALIASES = {
  'catalog-0002': ['Baahubali 2', 'Baahubali 2: The Conclusion'],
  'catalog-0027': ['Salaar: Part 1 - Ceasefire', 'Salaar Part 1 Ceasefire'],
  'catalog-0041': ['Ninne Pelladatha'],
  'catalog-0050': ['Son of Satyamurthy'],
  'catalog-0051': ['Attarintiki Daaredi'],
  'catalog-0119': ['HIT: The Second Case', 'Hit: The Second Case'],
  'catalog-0127': ['Yevade Subramanyam'],
  'catalog-0135': ['Tillu Square'],
  'catalog-0145': ['Hari Hara Veera Mallu: Part 1 - Sword vs Spirit', 'Hari Hara Veera Mallu Part 1'],
  'catalog-0159': ['Taxiwala', 'Taxi Waala'],
  'catalog-0168': ['Virata Parvam'],
  'catalog-0204': ['Lagaan'],
  'catalog-0255': ['Taare Zameen Par'],
  'catalog-0359': ['Masaan'],
  'catalog-0385': ['Toilet: Ek Prem Katha'],
  'catalog-0396': ['Laapataa Ladies', 'Lost Ladies'],
  'catalog-0374': ['Nayak: The Real Hero'],
  'catalog-0531': ['Mission: Impossible II', 'Mission Impossible II'],
  'catalog-0536': ['Mission: Impossible - Dead Reckoning Part One', 'Mission Impossible Dead Reckoning Part One'],
  'catalog-0554': ['First Blood', 'Rambo First Blood'],
  'catalog-0590': ['Kill Bill: Vol. 1', 'Kill Bill Vol 1'],
  'catalog-0591': ['Kill Bill: Vol. 2', 'Kill Bill Vol 2'],
  'catalog-0710': ['WALL·E', 'Wall E'],
  'catalog-0820': ['Indian 2'],
  'catalog-0839': ['Mouna Ragam'],
  'catalog-0850': ['Aayutha Ezhuthu'],
  'catalog-0853': ['Ponniyin Selvan: Part I', 'Ponniyin Selvan Part 1'],
  'catalog-0854': ['Ponniyin Selvan: Part II', 'Ponniyin Selvan Part 2'],
  'catalog-0868': ['24', '24: The Movie'],
  'catalog-0870': ['Singam 2', 'Singam II'],
  'catalog-0871': ['Si3', 'Singam 3'],
  'catalog-0883': ['Friends'],
  'catalog-0932': ['Aarambam'],
  'catalog-0949': ['Marudhu'],
  'catalog-0950': ['Madras'],
  'catalog-0951': ['Thozha'],
  'catalog-0975': ['Paava Kadhaigal'],
  'catalog-0986': ['Kadhalum Kadandhu Pogum'],
  'catalog-0995': ['Viduthalai Part 1', 'Viduthalai: Part I'],
  'catalog-0996': ['Viduthalai Part 2', 'Viduthalai: Part II'],
  'catalog-1004': ['Kantara: Chapter 1', 'Kantara Chapter 1'],
  'catalog-1007': ['777 Charlie', 'Charlie 777'],
  'catalog-1018': ['Sapta Sagaradaache Ello', 'Sapta Saagaradaache Ello'],
  'catalog-1043': ['Baahubali', 'Baahubali: The Beginning'],
  'catalog-1062': ['Pushpa', 'Pushpa: The Rise'],
  'catalog-1063': ['Pushpa 2', 'Pushpa 2: The Rule'],
  'catalog-1064': ['Devara', 'Devara: Part 1'],
  'catalog-1140': ['Nadodikattu'],
  'catalog-1154': ['The Goat Life', 'Aadujeevitham'],
  'catalog-1230': ['Gangs of Wasseypur - Part 1', 'Gangs of Wasseypur Part 1'],
  'catalog-1231': ['Gangs of Wasseypur - Part 2', 'Gangs of Wasseypur Part 2'],
  'catalog-1251': ['Parmanu: The Story of Pokhran', 'Parmanu'],
  'catalog-1415': ['The Empire Strikes Back', 'Star Wars Episode V The Empire Strikes Back'],
  'catalog-1537': ['Scream'],
  'catalog-1608': ['Kaavalan', 'Kavalan'],
  'catalog-1652': ['Sivaji: The Boss', 'Sivaji'],
  'catalog-1673': ['3'],
  'catalog-1674': ['Velaiilla Pattadhari', 'VIP'],
  'catalog-1675': ['Velaiilla Pattadhari 2', 'VIP 2'],
  'catalog-1698': ['Sir'],
  'catalog-1704': ['Naadodigal', 'Nadodigal'],
  'catalog-1706': ['Vagai Sooda Va'],
  'catalog-1745': ['Darling 2'],
  'catalog-1746': ['Masss', 'Massu Engira Masilamani'],
  'catalog-1747': ['Pisaasu', 'Pisasu'],
  'catalog-1765': ['Maamanithan'],
  'catalog-1775': ['Seethakaathi'],
  'catalog-1800': ['Lover'],
  'catalog-1801': ['Adavi Ramudu'],
  'catalog-1806': ['Alluda Majaka'],
  'catalog-1818': ['Arya'],
  'catalog-1819': ['Arya 2'],
  'catalog-1827': ['Racha'],
  'catalog-1830': ['Govindudu Andarivadele'],
  'catalog-1931': ['Glass Onion: A Knives Out Mystery', 'Glass Onion']
};
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
function normalize(s) {
  return String(s || '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase()
    .replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, '');
}
function yearOf(s) {
  const match = String(s || '').match(/^((?:18|19|20)\d{2})-/);
  if (!match) return null;
  const y = Number(match[1]);
  return y >= 1888 && y <= new Date().getFullYear() + 2 ? y : null;
}
async function getJson(url, tries = 0) {
  await sleep(GAP_MS);
  const response = await fetch(url, { headers: { Authorization: `Bearer ${TOKEN}`, Accept: 'application/json' } });
  if (response.status === 429 || response.status >= 500) {
    if (tries >= 4) throw new Error(`TMDB HTTP ${response.status} after retries`);
    const retry = Number(response.headers.get('retry-after'));
    await sleep(retry > 0 ? retry * 1000 : Math.min(1000 * (2 ** tries), 12000));
    return getJson(url, tries + 1);
  }
  if (!response.ok) throw new Error(`TMDB HTTP ${response.status}: ${(await response.text().catch(() => '')).slice(0, 120)}`);
  return response.json();
}
async function candidatesFor(row) {
  const titles = [...new Set([row.title, ...(ALIASES[row.id] || [])])];
  const allowed = new Set(titles.map(normalize));
  const all = new Map();
  const qTerms = titles.slice(0, 4);
  for (const query of qTerms) {
    const url = new URL(`${BASE}/search/movie`);
    url.searchParams.set('query', query);
    url.searchParams.set('include_adult', 'false');
    url.searchParams.set('language', 'en-US');
    url.searchParams.set('page', '1');
    const result = await getJson(url.toString());
    for (const candidate of result.results || []) {
      const titleN = normalize(candidate.title);
      const originalN = normalize(candidate.original_title);
      if (allowed.has(titleN) || allowed.has(originalN)) all.set(candidate.id, candidate);
    }
    const viable = [...all.values()].filter(c => c.original_language === EXPECTED[row.language] && yearOf(c.release_date) === Number(row.release_year));
    if (viable.length) break;
  }
  return [...all.values()];
}
function decide(row, candidates) {
  if (!candidates.length) return { match: null, reason: 'No exact title/alias match from TMDB search.' };
  const expectedLang = EXPECTED[row.language];
  const langCandidates = candidates.filter(c => c.original_language === expectedLang);
  if (!langCandidates.length) return { match: null, reason: `Candidates were found, but none has expected original language ${expectedLang || '(unknown)'}.` };
  const rowYear = Number(row.release_year) || 0;
  const yearCandidates = langCandidates.filter(c => yearOf(c.release_date) === rowYear);
  if (!rowYear || !yearCandidates.length) return { match: null, reason: `No exact year match (${rowYear || 'missing'}) in expected language; skipped to avoid wrong rating.` };
  yearCandidates.sort((a, b) => (Number(b.vote_count) || 0) - (Number(a.vote_count) || 0) || (Number(b.popularity) || 0) - (Number(a.popularity) || 0));
  const chosen = yearCandidates[0];
  const votes = Number(chosen.vote_count) || 0;
  const avg = Number(chosen.vote_average) || 0;
  if (votes < MIN_VOTES || avg <= 0) return { match: chosen, reason: `Exact title/year/language match, but only ${votes} TMDB votes; below threshold ${MIN_VOTES}.`, votes, rating: null };
  return { match: chosen, reason: `Exact normalized title/alias, matching year and original language; ${votes} TMDB votes.`, votes, rating: Math.round(avg * 10) / 10 };
}
function csvCell(value) { return `"${String(value ?? '').replace(/"/g, '""')}"`; }

async function main() {
  if (typeof fetch !== 'function') throw new Error('Node.js 18+ is required.');
  if (!TOKEN) throw new Error('Missing TMDB_API_TOKEN in .env.');
  const pool = mysql.createPool({
    host: process.env.DB_HOST || '127.0.0.1', port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root', password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'cinevault', waitForConnections: true,
    connectionLimit: 5, queueLimit: 0, charset: 'utf8mb4'
  });
  try {
    const [rows] = await pool.query(`SELECT id,title,language,release_year,rating FROM movies WHERE is_active=1 AND (rating IS NULL OR rating=0) ORDER BY language,id`);
    if (!rows.length) { console.log('No active movies are missing ratings.'); return; }
    const root = process.cwd();
    const backupDir = path.join(root, 'backups');
    const reportsDir = path.join(root, 'reports');
    fs.mkdirSync(backupDir, { recursive: true });
    fs.mkdirSync(reportsDir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backup = path.join(backupDir, `cinevault-ratings-before-v4-${stamp}.json`);
    const report = path.join(reportsDir, `cinevault-rating-fix-v4-${stamp}.csv`);
    fs.writeFileSync(backup, JSON.stringify(rows, null, 2), 'utf8');
    console.log(`Backup saved: ${path.relative(root, backup)}`);
    console.log(`Checking ${rows.length} active movies with rating 0/NULL. This run changes ratings only.`);
    let next = 0, checked = 0, updated = 0, skipped = 0, errors = 0;
    const reportRows = new Array(rows.length);
    async function worker() {
      while (true) {
        const i = next++;
        if (i >= rows.length) return;
        const row = rows[i];
        try {
          const candidates = await candidatesFor(row);
          const result = decide(row, candidates);
          let status = 'SKIPPED';
          if (result.match && result.rating != null && result.votes >= MIN_VOTES) {
            const [res] = await pool.execute(
              'UPDATE movies SET rating=? WHERE id=? AND is_active=1 AND (rating IS NULL OR rating=0)',
              [result.rating, row.id]
            );
            if (res.affectedRows > 0) { updated++; status = 'UPDATED'; } else { skipped++; status = 'SKIPPED'; }
          } else skipped++;
          reportRows[i] = {
            id: row.id, title: row.title, language: row.language, catalogue_year: row.release_year,
            status, tmdb_title: result.match?.title || '', tmdb_year: yearOf(result.match?.release_date) || '',
            tmdb_language: result.match?.original_language || '', vote_count: result.votes ?? (Number(result.match?.vote_count) || ''),
            tmdb_rating: result.rating ?? (result.match && Number(result.match.vote_average) > 0 ? Math.round(Number(result.match.vote_average) * 10) / 10 : ''),
            reason: result.reason, alternatives: JSON.stringify(candidates.map(c => ({title:c.title, year:yearOf(c.release_date), lang:c.original_language, votes:Number(c.vote_count)||0, rating:Number(c.vote_average)||0})))
          };
        } catch (e) {
          errors++;
          reportRows[i] = { id: row.id, title: row.title, language: row.language, catalogue_year: row.release_year, status: 'ERROR', reason: e.message };
        }
        checked++;
        if (checked % 20 === 0 || checked === rows.length) console.log(`Progress: ${checked}/${rows.length}; ratings updated ${updated}; skipped ${skipped}; errors ${errors}`);
      }
    }
    await Promise.all(Array.from({length: Math.min(CONCURRENCY, rows.length)}, worker));
    const keys = ['id','title','language','catalogue_year','status','tmdb_title','tmdb_year','tmdb_language','vote_count','tmdb_rating','reason','alternatives'];
    fs.writeFileSync(report, [keys.map(csvCell).join(','), ...reportRows.map(row => keys.map(k => csvCell(row?.[k])).join(','))].join('\r\n'), 'utf8');
    console.log('\n=== CineVault rating-only fix v4 summary ===');
    console.log(`Rows checked: ${rows.length}`);
    console.log(`Ratings updated: ${updated}`);
    console.log(`Skipped (unsafe/no eligible rating): ${skipped}`);
    console.log(`Errors: ${errors}`);
    console.log(`Backup: ${path.relative(root, backup)}`);
    console.log(`Review report: ${path.relative(root, report)}`);
    console.log('Only movies.rating was changed. Years, genres, posters, descriptions, shows, seats and bookings were untouched.');
  } finally { await pool.end(); }
}
main().catch(err => { console.error(`\nRating updater stopped: ${err.message}`); process.exitCode = 1; });
