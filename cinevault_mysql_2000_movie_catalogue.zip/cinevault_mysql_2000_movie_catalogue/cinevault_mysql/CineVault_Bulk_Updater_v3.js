'use strict';

/**
 * CineVault bulk metadata enrichment v3.
 * Bulk-processes all active records missing year, genre, or rating.
 * Matches normalized exact titles and selects the strongest TMDB candidate using
 * explicit year (when title contains one), an existing year, vote count,
 * popularity, and a soft original-language preference. It does NOT hard-reject
 * otherwise exact titles because the catalogue's language labels may not always
 * equal a film's original language.
 *
 * Saves a backup and a CSV review report. Does not modify bookings/shows/seats.
 */
require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const mysql = require('mysql2/promise');

const TMDB_TOKEN = (process.env.TMDB_API_TOKEN || '').trim();
const TMDB_BASE = 'https://api.themoviedb.org/3';
const IMAGE_BASE = 'https://image.tmdb.org/t/p/w500';
const CONCURRENCY = 3;
const REQUEST_GAP_MS = 250;
const MAX_RETRIES = 5;
const EXPECTED_LANGUAGES = { Telugu: 'te', Hindi: 'hi', English: 'en', Tamil: 'ta', Kannada: 'kn', Malayalam: 'ml', Korean: 'ko' };
const TMDB_GENRES = {
  28: 'Action', 12: 'Adventure', 16: 'Animation', 35: 'Comedy', 80: 'Crime',
  99: 'Documentary', 18: 'Drama', 10751: 'Family', 14: 'Fantasy', 36: 'History',
  27: 'Horror', 10402: 'Music', 9648: 'Mystery', 10749: 'Romance', 878: 'Science Fiction',
  10770: 'TV Movie', 53: 'Thriller', 10752: 'War', 37: 'Western'
};
const sleep = ms => new Promise(r => setTimeout(r, ms));
const titleYear = value => {
  const m = String(value || '').match(/\(((?:18|19|20)\d{2})\)\s*$/);
  return m ? Number(m[1]) : null;
};
const stripTitleYear = value => String(value || '').replace(/\s*\(((?:18|19|20)\d{2})\)\s*$/, '').trim();
function normalizeTitle(value) {
  return stripTitleYear(value).normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase()
    .replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, '');
}
function yearFromReleaseDate(date) {
  const m = String(date || '').match(/^((?:18|19|20)\d{2})-/);
  if (!m) return null;
  const y = Number(m[1]);
  return y >= 1888 && y <= new Date().getFullYear() + 2 ? y : null;
}
async function tmdbGet(url, attempt = 0) {
  await sleep(REQUEST_GAP_MS);
  const r = await fetch(url, { headers: { Authorization: `Bearer ${TMDB_TOKEN}`, Accept: 'application/json' } });
  if (r.status === 429 || r.status >= 500) {
    if (attempt >= MAX_RETRIES) throw new Error(`TMDB API returned HTTP ${r.status} after retries`);
    const retryAfter = Number(r.headers.get('retry-after'));
    await sleep(Number.isFinite(retryAfter) && retryAfter > 0 ? retryAfter * 1000 : Math.min(1000 * (2 ** attempt), 15000));
    return tmdbGet(url, attempt + 1);
  }
  if (!r.ok) throw new Error(`TMDB API HTTP ${r.status}: ${(await r.text().catch(() => '')).slice(0, 200)}`);
  return r.json();
}
function selectBestCandidate(row, results) {
  const target = normalizeTitle(row.title);
  const explicitYear = titleYear(row.title);
  let candidates = (results || []).filter(c => normalizeTitle(c.title) === target || normalizeTitle(c.original_title) === target);
  if (!candidates.length) return { match: null, reason: 'no exact normalized title match', candidates: [] };
  // An explicit year embedded in the catalogue title is a strong disambiguator.
  if (explicitYear) {
    const byExplicitYear = candidates.filter(c => yearFromReleaseDate(c.release_date) === explicitYear);
    if (byExplicitYear.length) candidates = byExplicitYear;
  }
  const expectedLanguage = EXPECTED_LANGUAGES[row.language];
  const scored = candidates.map(c => {
    const year = yearFromReleaseDate(c.release_date);
    const voteCount = Number(c.vote_count) || 0;
    const popularity = Number(c.popularity) || 0;
    const languageBonus = expectedLanguage && c.original_language === expectedLanguage ? 2 : 0;
    const explicitYearBonus = explicitYear && year === explicitYear ? 1000 : 0;
    const existingYearBonus = Number(row.release_year) > 0 && year === Number(row.release_year) ? 25 : 0;
    const score = explicitYearBonus + existingYearBonus + Math.log10(voteCount + 1) * 10 + Math.log10(popularity + 1) * 2 + languageBonus;
    return { c, year, voteCount, popularity, score };
  }).sort((a, b) => b.score - a.score);
  const chosen = scored[0];
  const runnerUp = scored[1];
  const reason = scored.length > 1 ? `best exact-title candidate selected from ${scored.length}; year=${chosen.year || 'unknown'}, original_language=${chosen.c.original_language || 'unknown'}, votes=${chosen.voteCount}` : `single exact-title candidate; year=${chosen.year || 'unknown'}, original_language=${chosen.c.original_language || 'unknown'}, votes=${chosen.voteCount}`;
  return { match: chosen.c, reason, candidates: scored.map(s => ({ year: s.year, lang: s.c.original_language, votes: s.voteCount, popularity: s.popularity, score: Math.round(s.score * 100) / 100 })), closeCall: !!runnerUp && Math.abs(chosen.score - runnerUp.score) < 3 };
}
function primaryGenre(c) { for (const id of c.genre_ids || []) if (TMDB_GENRES[id]) return TMDB_GENRES[id]; return null; }
function fitText(value, limit) {
  const t = String(value || '').trim();
  if (!limit || limit < 1 || Array.from(t).length <= limit) return t;
  if (limit === 1) return '…';
  return Array.from(t).slice(0, limit - 1).join('').trimEnd() + '…';
}
function csvCell(v) { const s = String(v ?? ''); return `"${s.replace(/"/g, '""')}"`; }

async function main() {
  if (typeof fetch !== 'function') throw new Error('Node.js 18 or newer is required.');
  if (!TMDB_TOKEN) throw new Error('Missing TMDB_API_TOKEN. Add your TMDB API Read Access Token to .env.');
  const pool = mysql.createPool({ host: process.env.DB_HOST || '127.0.0.1', port: Number(process.env.DB_PORT || 3306), user: process.env.DB_USER || 'root', password: process.env.DB_PASSWORD || '', database: process.env.DB_NAME || 'cinevault', waitForConnections: true, connectionLimit: 5, queueLimit: 0, charset: 'utf8mb4' });
  try {
    const [cols] = await pool.query(`SELECT DATA_TYPE, CHARACTER_MAXIMUM_LENGTH FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='movies' AND COLUMN_NAME='description' LIMIT 1`);
    const rawLimit = cols[0]?.CHARACTER_MAXIMUM_LENGTH;
    const descriptionLimit = rawLimit == null ? null : Number(rawLimit);
    console.log(`Description limit: ${descriptionLimit || 'unknown'} characters.`);
    const [rows] = await pool.query(`SELECT id,title,language,release_year,genre,rating,image_url,description FROM movies WHERE is_active=1 AND (release_year=0 OR genre IS NULL OR genre='' OR genre='Unclassified' OR rating IS NULL OR rating=0) ORDER BY language,id`);
    if (!rows.length) { console.log('No active movies need year, genre, or rating enrichment.'); return; }
    const root = process.cwd(); const backupDir = path.join(root, 'backups'); const reportsDir = path.join(root, 'reports');
    fs.mkdirSync(backupDir, { recursive: true }); fs.mkdirSync(reportsDir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupPath = path.join(backupDir, `cinevault-movies-before-enrichment-v3-${stamp}.json`);
    const reportPath = path.join(reportsDir, `cinevault-enrichment-v3-${stamp}.csv`);
    fs.writeFileSync(backupPath, JSON.stringify(rows, null, 2), 'utf8');
    console.log(`Backup saved: ${path.relative(root, backupPath)}`);
    console.log(`Checking ${rows.length} active rows with incomplete metadata...`);
    console.log('Using exact normalized titles; ambiguous titles are ranked by explicit title year, existing year, vote count, popularity, and a soft language preference. Review the CSV report.');
    let cursor = 0, processed = 0, updated = 0, skipped = 0, failures = 0;
    const reportRows = [];
    async function worker() {
      while (true) {
        const idx = cursor++;
        if (idx >= rows.length) return;
        const row = rows[idx]; processed++;
        try {
          const url = new URL(`${TMDB_BASE}/search/movie`); url.searchParams.set('query', row.title); url.searchParams.set('include_adult', 'false'); url.searchParams.set('language', 'en-US'); url.searchParams.set('page', '1');
          const search = await tmdbGet(url.toString());
          const outcome = selectBestCandidate(row, search.results);
          if (!outcome.match) { skipped++; reportRows.push({ id: row.id, title: row.title, status: 'SKIPPED', reason: outcome.reason }); continue; }
          const c = outcome.match; const year = yearFromReleaseDate(c.release_date); const genre = primaryGenre(c);
          const votes = Number(c.vote_count) || 0; const avg = Number(c.vote_average) || 0;
          const rating = avg > 0 && votes >= 5 ? Math.round(avg * 10) / 10 : null;
          const poster = c.poster_path ? `${IMAGE_BASE}${c.poster_path}` : null;
          const overview = fitText(c.overview || '', descriptionLimit);
          const set = [], args = [];
          if (Number(row.release_year) === 0 && year) { set.push('release_year=?'); args.push(year); }
          if ((!row.genre || row.genre === 'Unclassified') && genre) { set.push('genre=?'); args.push(genre); }
          if ((row.rating == null || Number(row.rating) === 0) && rating !== null) { set.push('rating=?'); args.push(rating); }
          if (poster) { set.push('image_url=?'); args.push(poster); }
          if (overview && (!row.description || row.description.startsWith('Catalogue entry imported from the supplied title list.'))) { set.push('description=?'); args.push(overview); }
          if (!set.length) { skipped++; reportRows.push({ id: row.id, title: row.title, status: 'SKIPPED', reason: 'match found but no eligible fields to update', selected_year: year, original_language: c.original_language, vote_count: votes }); continue; }
          args.push(row.id);
          const [res] = await pool.execute(`UPDATE movies SET ${set.join(', ')} WHERE id=? AND is_active=1`, args);
          if (res.affectedRows > 0) updated++; else skipped++;
          reportRows.push({ id: row.id, title: row.title, status: res.affectedRows > 0 ? 'UPDATED' : 'SKIPPED', selected_year: year, selected_title: c.title, original_language: c.original_language, vote_count: votes, popularity: c.popularity, rating_applied: rating ?? '', close_call: outcome.closeCall ? 'REVIEW' : '', reason: outcome.reason, alternatives: JSON.stringify(outcome.candidates) });
        } catch (e) { failures++; reportRows.push({ id: row.id, title: row.title, status: 'ERROR', reason: e.message }); }
        if (processed % 50 === 0 || processed === rows.length) console.log(`Progress: ${processed}/${rows.length}; updated ${updated}; skipped ${skipped}; errors ${failures}`);
      }
    }
    await Promise.all(Array.from({ length: Math.min(CONCURRENCY, rows.length) }, worker));
    const keys = ['id','title','status','selected_title','selected_year','original_language','vote_count','popularity','rating_applied','close_call','reason','alternatives'];
    fs.writeFileSync(reportPath, [keys.map(csvCell).join(','), ...reportRows.map(r => keys.map(k => csvCell(r[k])).join(','))].join('\r\n'), 'utf8');
    console.log('\n=== CineVault metadata enrichment summary (v3) ===');
    console.log(`Rows checked: ${rows.length}`); console.log(`Rows updated: ${updated}`); console.log(`Rows skipped: ${skipped}`); console.log(`Errors: ${failures}`);
    console.log(`Backup: ${path.relative(root, backupPath)}`); console.log(`Review report: ${path.relative(root, reportPath)}`);
    console.log('Ratings were applied only when TMDB vote_count >= 5. See the CSV for chosen candidates and alternatives.');
    console.log('Bookings, shows, seats, and show_seats were not modified.');
  } finally { await pool.end(); }
}
main().catch(e => { console.error(`\nCineVault enrichment stopped: ${e.message}`); process.exitCode = 1; });
