# CineVault — MySQL Database Phase

This package upgrades the existing CineVault Flask API from temporary JSON storage to **MySQL 8.0+** while keeping the current cinematic frontend and seat-selection design.

## What is included

- `app.py` — Flask REST API connected to MySQL.
- `database/schema.sql` — normalized tables, constraints, triggers and the occupancy stored procedure.
- `seed_database.py` — imports your supplied 2,000-title list (deduplicated by title/language), keeps the 40 curated CineVault demo records, and creates three screens, 48 seats per screen, first-week curated screenings, and a 60-day catalogue rotation so every catalogue title receives a generated demo screening.
- `database/movie_catalogue.csv` — normalized import data from the supplied list.
- `database/source_movie_list.txt` — original 2,000 numbered entries preserved as supplied.
- `database/catalogue_import_report.txt` — counts, language assignments and data-quality notes.
- `frontend/` — the existing CineVault frontend, with a screening-date selector added so it can work with real show dates.
- `.env.example` — database connection settings template.
- `requirements.txt` — Python dependencies.

## Catalogue and screening data

The source file contains **2,000 numbered title entries**. The import CSV deduplicates repeated title/language pairs, producing **1,584 unique title/language entries** from that list. The seed script also keeps the 40 curated CineVault demo records and skips catalogue entries already represented by those curated records. The final inserted total is printed by the seed script. The supplied list contains titles only, so unknown release years, ratings, runtimes and genres are marked as not supplied / unclassified instead of being invented. The ₹220 default for imported entries is an illustrative demo price, not a real theatre price.

The seed script creates three screens, each with 48 seats (rows A–F, seats 1–8). The first week repeats the curated demo films, then the following 60 days rotate through the full catalogue so each title gets at least one generated screening. These generated screenings are for testing the booking flow only; they are not real-world cinema schedules. Each screen has one movie per showtime slot. Ratings and prices for curated demo records are illustrative project data, not live ratings or real theatre listings. For titles imported from your source list, missing metadata is explicitly marked as unlisted/unclassified. Language assignments in the mixed-language section are inferred from section ranges and should be reviewed before public release.

Searching is database-backed: title, genre, description, language and release year are searchable. The website includes language filtering and server-side pagination, so it only renders 24 results at a time. The 2,000 source entries contain repeated titles; 1,584 unique title/language entries are imported from the list. Every imported title is assigned a generated demo screening in the extended schedule, so the end-to-end booking flow can be tested for the whole catalogue. These dates/times are placeholders, not actual theatre listings. More titles can be added using `POST /api/movies`, then scheduled using `POST /api/admin/shows` (examples below).

## Setup in VS Code on Windows

### 1. Install and start MySQL

Install MySQL Server 8.0 or newer and MySQL Workbench if they are not already installed. Make sure the MySQL service is running.

### 2. Create the tables, triggers and procedure

1. Open MySQL Workbench and connect to your local MySQL server.
2. Open `database/schema.sql` from this project.
3. Execute the entire script. It creates the `cinevault` database and its tables, then defines the triggers and stored procedure.

### 3. Configure the database password

In the VS Code project folder, copy `.env.example` to `.env` and edit the password to match your MySQL account.

PowerShell:

```powershell
Copy-Item .env.example .env
```

Example `.env` (change the password to your own local MySQL password):

```dotenv
MYSQL_HOST=127.0.0.1
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=your_actual_mysql_password
MYSQL_DATABASE=cinevault
```

Do not share your real password or commit `.env` to a public repository.

### 4. Install Python packages

Open the `cinevault_mysql` folder in VS Code, then choose **Terminal → New Terminal**:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

If PowerShell blocks virtual-environment activation, switch the VS Code terminal profile to Command Prompt and run:

```bat
.venv\Scripts\activate.bat
```

### 5. Seed the catalogue and showtimes

Run this once after the schema has been created and `.env` has been configured:

```powershell
python seed_database.py
```

The script is safe to re-run for the same dates; it uses insert/update logic to avoid duplicating the seeded catalogue and show slots. It will print the number of movies, screens and show slots prepared.

### 6. Start CineVault

```powershell
python app.py
```

Open **http://127.0.0.1:5000** in Chrome. Keep the terminal running while you use the website. Do not double-click `index.html`, because the frontend needs the Flask API.

## DBMS concepts included

- **Primary and foreign keys** connect movies, screens, shows, seats and bookings.
- **Unique constraint** `uq_screen_date_time` prevents two films being assigned to the same screen at the same date and time.
- **Transactions and row locks** validate seat availability and create a booking atomically.
- **Unique active-seat key** prevents the same seat for a show from being actively booked twice.
- **Trigger `trg_booking_seats_before_insert`** rejects a seat that is not available.
- **Trigger `trg_booking_seats_after_insert`** marks a seat as booked after a booking-seat row is inserted.
- **Trigger `trg_booking_seats_after_release`** marks a seat available when its booking-seat allocation is released.
- **Trigger `trg_booking_cancel_release_seats`** releases all active seat allocations when a confirmed booking is cancelled.
- **Stored procedure `sp_show_occupancy()`** returns capacity, booked seats and occupancy percentage per show. Studio Insights calls this procedure.

No payment is collected. This is a local academic demo, not a production ticketing service; it has no login or admin authentication.

## API routes

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/health` | Check API and MySQL connection |
| GET | `/api/movies?q=inception&genre=all&language=all&sort=rating&limit=24&offset=0` | Search, filter, sort and paginate catalogue |
| POST | `/api/movies` | Add a movie to the catalogue |
| GET | `/api/screens` | List active screens and features |
| GET | `/api/shows?movie_id=velvet` | List upcoming shows for a movie |
| GET | `/api/shows?date=YYYY-MM-DD` | List shows for a date |
| POST | `/api/admin/shows` | Schedule a movie in a screen/time slot |
| GET | `/api/shows/<show_id>/seats` | Load seat availability and prices |
| GET | `/api/bookings` | List bookings and ticket status |
| POST | `/api/bookings` | Create a booking (JSON: `show_id`, `seats`, `experience`, `preference`) |
| POST | `/api/bookings/<ref>/cancel` | Cancel a confirmed booking; trigger releases seats |
| GET | `/api/insights` | Counts, recent bookings and occupancy from stored procedure |

### Example: add a movie

Send JSON to `POST http://127.0.0.1:5000/api/movies`:

```json
{
  "id": "my-new-film",
  "title": "My New Film",
  "genre": "Drama",
  "year": 2026,
  "duration": "2h 05m",
  "rating": 8.1,
  "price": 230,
  "tag": "NEW ARRIVAL",
  "desc": "A short demo description for this movie.",
  "language": "English",
  "certificate": "UA"
}
```

### Example: schedule that movie

First check `/api/screens` to copy a screen ID. Then send JSON to `POST http://127.0.0.1:5000/api/admin/shows`:

```json
{
  "movie_id": "my-new-film",
  "screen_id": "screen-01",
  "date": "2026-10-30",
  "time": "18:30"
}
```

Choose a future date and a screen/time slot that is not already occupied. Once a show is scheduled, it appears in the movie's booking options.

## Troubleshooting

- **MySQL connection error:** confirm the MySQL service is running and the values in `.env` are correct.
- **Unknown database/table/procedure:** execute `database/schema.sql` first, then `python seed_database.py`.
- **No upcoming show:** run `python seed_database.py` to create the first-week demo slots and extended catalogue rotation, or schedule the title with the admin endpoint.
- **Port 5000 is in use:** close the other local Flask server or change `PORT` before starting the app.
