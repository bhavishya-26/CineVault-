/**
 * CineVault Showtime Backfill
 * Adds upcoming DEMO screenings only for active movies that have no upcoming show.
 * Also fills any missing physical seat rows for upcoming shows using INSERT IGNORE.
 * Does NOT update/delete movies, ratings, genres, posters, bookings, or existing seat statuses.
 *
 * Run from the CineVault project folder:
 *   node CineVault_Showtime_Backfill.js
 */
'use strict';

require('dotenv').config();
const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

const SHOW_DAYS = 120;
const SHOW_TIMES = ['09:00:00', '12:15:00', '15:30:00', '18:45:00', '22:00:00'];

function csvEscape(value) {
  const s = value === null || value === undefined ? '' : String(value);
  return `"${s.replace(/"/g, '""')}"`;
}

function dateOffset(dateText, offset) {
  const base = new Date(`${String(dateText).slice(0, 10)}T00:00:00Z`);
  base.setUTCDate(base.getUTCDate() + offset);
  return `${base.getUTCFullYear()}-${String(base.getUTCMonth() + 1).padStart(2, '0')}-${String(base.getUTCDate()).padStart(2, '0')}`;
}

function compactDate(dateText) { return String(dateText).replace(/-/g, ''); }
function compactTime(timeText) { return String(timeText).replace(/:/g, '').slice(0, 4); }

async function main() {
  const pool = mysql.createPool({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'cinevault',
    waitForConnections: true,
    connectionLimit: 4,
    queueLimit: 0,
    charset: 'utf8mb4'
  });

  let conn;
  try {
    conn = await pool.getConnection();
    const [[todayRow]] = await conn.query("SELECT DATE_FORMAT(CURDATE(), '%Y-%m-%d') AS today");
    const today = String(todayRow.today).slice(0, 10);

    const [screens] = await conn.query(`
      SELECT sc.id, sc.name, COUNT(se.seat_id) AS seat_count
      FROM screens sc
      LEFT JOIN seats se ON se.screen_id = sc.id
      WHERE sc.is_active = 1
      GROUP BY sc.id, sc.name
      HAVING COUNT(se.seat_id) > 0
      ORDER BY sc.id
    `);
    if (!screens.length) throw new Error('No active screens with physical seats were found. Nothing was changed.');

    const [missingMovies] = await conn.query(`
      SELECT m.id, m.title, COALESCE(m.base_price, 220) AS base_price
      FROM movies m
      WHERE m.is_active = 1
        AND NOT EXISTS (
          SELECT 1 FROM shows sh
          WHERE sh.movie_id = m.id AND sh.show_date >= CURDATE()
        )
      ORDER BY m.id
    `);

    const [existingShows] = await conn.query(`
      SELECT sh.id, sh.movie_id, sh.screen_id,
             DATE_FORMAT(sh.show_date, '%Y-%m-%d') AS show_date,
             TIME_FORMAT(sh.show_time, '%H:%i:%s') AS show_time
      FROM shows sh
      WHERE sh.show_date >= CURDATE()
    `);

    const usedSlots = new Set(existingShows.map(s => `${s.screen_id}|${s.show_date}|${s.show_time}`));
    const plan = [];
    let movieIndex = 0;

    for (let dayOffset = 1; dayOffset <= SHOW_DAYS && movieIndex < missingMovies.length; dayOffset++) {
      const showDate = dateOffset(today, dayOffset);
      for (const showTime of SHOW_TIMES) {
        for (const screen of screens) {
          if (movieIndex >= missingMovies.length) break;
          const slotKey = `${screen.id}|${showDate}|${showTime}`;
          if (usedSlots.has(slotKey)) continue;
          const movie = missingMovies[movieIndex++];
          const showId = `show-${movie.id}-${screen.id}-${compactDate(showDate)}-${compactTime(showTime)}`;
          plan.push({
            show_id: showId,
            movie_id: movie.id,
            title: movie.title,
            screen_id: screen.id,
            screen_name: screen.name,
            show_date: showDate,
            show_time: showTime,
            base_price: Math.max(0, Math.trunc(Number(movie.base_price) || 220)),
            seat_count_expected: Number(screen.seat_count)
          });
          usedSlots.add(slotKey);
        }
      }
    }

    if (plan.length !== missingMovies.length) {
      throw new Error(`Only ${plan.length} free demo show slots found for ${missingMovies.length} movies across ${SHOW_DAYS} days. Nothing was changed; increase SHOW_DAYS before retrying.`);
    }

    const root = process.cwd();
    const backupDir = path.join(root, 'backups');
    const reportsDir = path.join(root, 'reports');
    fs.mkdirSync(backupDir, { recursive: true });
    fs.mkdirSync(reportsDir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupPath = path.join(backupDir, `cinevault-showtime-backfill-plan-${stamp}.json`);
    const reportPath = path.join(reportsDir, `cinevault-showtime-backfill-${stamp}.csv`);
    fs.writeFileSync(backupPath, JSON.stringify({
      generated_at: new Date().toISOString(),
      note: 'Pre-change plan/manifest for additive demo-show inserts. Existing rows are not modified or deleted.',
      today,
      show_days: SHOW_DAYS,
      movies_without_upcoming_shows: missingMovies,
      existing_upcoming_shows_count: existingShows.length,
      planned_new_shows: plan
    }, null, 2), 'utf8');
    console.log(`Database date: ${today}`);
    console.log(`Active screens: ${screens.length}; free physical seats per screen: ${screens.map(s => `${s.name}=${s.seat_count}`).join(', ')}`);
    console.log(`Active movies without upcoming shows: ${missingMovies.length}`);
    console.log(`New demo showtimes planned: ${plan.length} across the next ${SHOW_DAYS} days.`);
    console.log(`Plan backup saved: ${path.relative(root, backupPath)}`);

    if (plan.length === 0) {
      console.log('All active movies already have an upcoming show. Checking seat inventory only.');
    }

    await conn.beginTransaction();
    let showsInserted = 0;
    let newSeatRows = 0;

    for (let i = 0; i < plan.length; i++) {
      const s = plan[i];
      await conn.query(
        `INSERT INTO shows (id, movie_id, screen_id, show_date, show_time, base_price)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [s.show_id, s.movie_id, s.screen_id, s.show_date, s.show_time, s.base_price]
      );
      showsInserted++;
      const [seatResult] = await conn.query(
        `INSERT IGNORE INTO show_seats (show_id, screen_id, seat_id, status)
         SELECT ?, seats.screen_id, seats.seat_id, 'available'
         FROM seats WHERE seats.screen_id = ?`,
        [s.show_id, s.screen_id]
      );
      newSeatRows += Number(seatResult.affectedRows || 0);
      if ((i + 1) % 100 === 0 || i + 1 === plan.length) {
        console.log(`Progress: ${i + 1}/${plan.length} shows; ${newSeatRows} seat rows added`);
      }
    }

    // Repair only missing seat rows for all upcoming active-screen shows. INSERT IGNORE
    // preserves existing booked/available statuses and does not duplicate seat keys.
    const [upcoming] = await conn.query(`
      SELECT sh.id, sh.screen_id
      FROM shows sh
      JOIN movies m ON m.id = sh.movie_id AND m.is_active = 1
      JOIN screens sc ON sc.id = sh.screen_id AND sc.is_active = 1
      WHERE sh.show_date >= CURDATE()
    `);
    let repairedSeatRows = 0;
    for (const show of upcoming) {
      const [seatResult] = await conn.query(
        `INSERT IGNORE INTO show_seats (show_id, screen_id, seat_id, status)
         SELECT ?, seats.screen_id, seats.seat_id, 'available'
         FROM seats WHERE seats.screen_id = ?`,
        [show.id, show.screen_id]
      );
      repairedSeatRows += Number(seatResult.affectedRows || 0);
    }

    await conn.commit();

    const reportLines = [
      ['show_id', 'movie_id', 'title', 'screen_id', 'screen_name', 'show_date', 'show_time', 'base_price', 'seat_count_expected', 'status'].join(',')
    ];
    for (const s of plan) {
      reportLines.push([
        s.show_id, s.movie_id, s.title, s.screen_id, s.screen_name,
        s.show_date, s.show_time, s.base_price, s.seat_count_expected, 'INSERTED_DEMO_SHOW'
      ].map(csvEscape).join(','));
    }
    fs.writeFileSync(reportPath, reportLines.join('\n') + '\n', 'utf8');

    console.log('\n=== CineVault showtime backfill summary ===');
    console.log(`New demo shows inserted: ${showsInserted}`);
    console.log(`New seat rows for inserted shows: ${newSeatRows}`);
    console.log(`Additional missing seat rows filled across existing upcoming shows: ${repairedSeatRows}`);
    console.log(`Upcoming shows checked for seat inventory: ${upcoming.length}`);
    console.log('Existing shows, movies, ratings, genres, posters, descriptions, bookings and existing seat statuses were not updated or deleted.');
    console.log('Note: generated showtimes are DEMO data, not live theatre listings.');
    console.log(`Report saved: ${path.relative(root, reportPath)}`);
  } catch (error) {
    if (conn) {
      try { await conn.rollback(); } catch { /* preserve original error */ }
    }
    console.error('\nShowtime backfill failed. Transaction rolled back; no partial inserts were committed.');
    console.error(error.message || error);
    process.exitCode = 1;
  } finally {
    if (conn) conn.release();
    await pool.end();
  }
}

main().catch(error => {
  console.error(error.message || error);
  process.exitCode = 1;
});
