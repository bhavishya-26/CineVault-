
const express = require("express");
const mysql = require("mysql2/promise");
const path = require("path");
const crypto = require("crypto");
require("dotenv").config();

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const pool = mysql.createPool({
  host: process.env.DB_HOST || "127.0.0.1",
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "cinevault",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// 1. Health check
app.get("/api/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({
      success: true,
      message: "CineVault connected to MySQL!"
    });
  } catch (error) {
    console.error("MYSQL ERROR:", error.code, error.message);
    res.status(500).json({
      success: false,
      message: "MySQL connection failed."
    });
  }
});

// 2. Movie catalogue
app.get("/api/movies", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        id, title, genre, release_year, duration, rating,
        base_price, tag, description, bg, orb, orb_light,
        accent, image_url, language, certificate,
        featured, is_active
      FROM movies
      WHERE is_active = 1
      ORDER BY featured DESC, title ASC
      LIMIT 2000
    `);

    res.json(rows);
  } catch (error) {
    console.error("MOVIES ERROR:", error.code, error.message);
    res.status(500).json({
      success: false,
      message: "Could not load movies."
    });
  }
});

// 3. Movie showtimes
app.get("/api/movies/:movieId/shows", async (req, res) => {
  try {
    const { movieId } = req.params;
    const date = req.query.date || null;

    if (date && !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({
        success: false,
        message: "Date must use YYYY-MM-DD format."
      });
    }

    const [shows] = await pool.execute(`
      SELECT
        sh.id,
        sh.movie_id,
        DATE_FORMAT(sh.show_date, '%Y-%m-%d') AS show_date,
        TIME_FORMAT(sh.show_time, '%H:%i') AS show_time,
        sh.base_price,
        sc.name AS screen_name,
        sc.label AS screen_label,
        COUNT(ss.seat_id) AS total_seats,
        COALESCE(SUM(ss.status = 'available'), 0)
          AS available_seats
      FROM shows sh
      JOIN screens sc ON sc.id = sh.screen_id
      LEFT JOIN show_seats ss ON ss.show_id = sh.id
      WHERE sh.movie_id = ?
        AND sh.show_date >= CURDATE()
        AND (? IS NULL OR sh.show_date = ?)
      GROUP BY
        sh.id, sh.movie_id, sh.show_date, sh.show_time,
        sh.base_price, sc.name, sc.label
      ORDER BY sh.show_date, sh.show_time, sc.name
    `, [movieId, date, date]);

    res.json(shows);
  } catch (error) {
    console.error("SHOWTIMES ERROR:", error.code, error.message);
    res.status(500).json({
      success: false,
      message: "Could not load showtimes."
    });
  }
});

// 4. Seat availability for a show
app.get("/api/shows/:showId/seats", async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT
        ss.show_id,
        ss.seat_id,
        ss.status,
        s.row_label,
        s.seat_number,
        s.zone,
        s.seat_type,
        s.is_aisle,
        s.is_center,
        sh.base_price,
        sh.base_price +
          CASE
            WHEN s.seat_type = 'Premium' THEN 50
            WHEN s.seat_type = 'Recliner' THEN 120
            ELSE 0
          END AS seat_price
      FROM show_seats ss
      JOIN shows sh ON sh.id = ss.show_id
      JOIN seats s
        ON s.screen_id = ss.screen_id
       AND s.seat_id = ss.seat_id
      WHERE ss.show_id = ?
      ORDER BY s.row_label, s.seat_number
    `, [req.params.showId]);

    if (rows.length === 0) {
      const [show] = await pool.execute(
        "SELECT id FROM shows WHERE id = ?",
        [req.params.showId]
      );

      if (show.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Showtime not found."
        });
      }
    }

    res.json(rows);
  } catch (error) {
    console.error("SEATS ERROR:", error.code, error.message);
    res.status(500).json({
      success: false,
      message: "Could not load seats."
    });
  }
});

// 5. Create a test booking
app.post("/api/bookings", async (req, res) => {
  let connection;
  let transactionStarted = false;

  try {
    const {
      showId,
      seats,
      experience = "ac",
      preference = "all"
    } = req.body;

    if (
      typeof showId !== "string" ||
      !showId.trim() ||
      !Array.isArray(seats) ||
      seats.length < 1 ||
      seats.length > 10 ||
      seats.some(id => typeof id !== "string" || !id.trim()) ||
      new Set(seats).size !== seats.length
    ) {
      return res.status(400).json({
        success: false,
        message: "Choose 1 to 10 different valid seats."
      });
    }

    if (!["ac", "classic"].includes(experience)) {
      return res.status(400).json({
        success: false,
        message: "Invalid cinema experience."
      });
    }

    if (!["all", "center", "aisle", "recliner"].includes(preference)) {
      return res.status(400).json({
        success: false,
        message: "Invalid seat preference."
      });
    }

    connection = await pool.getConnection();
    await connection.beginTransaction();
    transactionStarted = true;

    // Lock the screening while checking availability.
    const [shows] = await connection.execute(
      "SELECT id FROM shows WHERE id = ? FOR UPDATE",
      [showId]
    );

    if (shows.length === 0) {
      const error = new Error("Showtime not found.");
      error.statusCode = 404;
      throw error;
    }

    const placeholders = seats.map(() => "?").join(",");

    const [seatRows] = await connection.query(`
      SELECT ss.seat_id, ss.status, s.seat_type, sh.base_price
      FROM show_seats ss
      JOIN shows sh ON sh.id = ss.show_id
      JOIN seats s
        ON s.screen_id = ss.screen_id
       AND s.seat_id = ss.seat_id
      WHERE ss.show_id = ?
        AND ss.seat_id IN (${placeholders})
      FOR UPDATE
    `, [showId, ...seats]);

    if (seatRows.length !== seats.length) {
      const error = new Error(
        "Some selected seats do not exist for this show."
      );
      error.statusCode = 400;
      throw error;
    }

    if (seatRows.some(seat => seat.status !== "available")) {
      const error = new Error(
        "A selected seat is already booked. Please choose another."
      );
      error.statusCode = 409;
      throw error;
    }

    const selectedSeats = seats.map(seatId => {
      const seat = seatRows.find(row => row.seat_id === seatId);
      const extra =
        seat.seat_type === "Premium" ? 50 :
        seat.seat_type === "Recliner" ? 120 : 0;

      return {
        seatId,
        price: Number(seat.base_price) + extra
      };
    });

    const totalPrice = selectedSeats.reduce(
      (sum, seat) => sum + seat.price,
      0
    );

    const bookingRef =
      "CV" + crypto.randomBytes(5).toString("hex").toUpperCase();

    const [booking] = await connection.execute(`
      INSERT INTO bookings
        (booking_ref, show_id, experience, preference,
         status, total_price)
      VALUES (?, ?, ?, ?, 'Confirmed', ?)
    `, [bookingRef, showId, experience, preference, totalPrice]);

    for (const seat of selectedSeats) {
      await connection.execute(`
        INSERT INTO booking_seats
          (booking_id, show_id, seat_id, seat_price, status)
        VALUES (?, ?, ?, ?, 'Active')
      `, [booking.insertId, showId, seat.seatId, seat.price]);
    }

    await connection.commit();
    transactionStarted = false;

    res.status(201).json({
      success: true,
      message: "Booking created successfully.",
      bookingId: booking.insertId,
      bookingRef,
      showId,
      seats: selectedSeats,
      totalPrice,
      currency: "INR",
      paymentStatus: "Development demo; no payment taken"
    });
  } catch (error) {
    if (connection && transactionStarted) {
      await connection.rollback();
    }

    console.error("BOOKING ERROR:", error.code || "", error.message);

    res.status(error.statusCode || 500).json({
      success: false,
      message: error.message || "Could not create booking."
    });
  } finally {
    if (connection) connection.release();
  }
});

// 6. Look up a booking by reference
app.get("/api/bookings/:bookingRef", async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT
        b.id AS booking_id,
        b.booking_ref,
        b.status AS booking_status,
        b.experience,
        b.preference,
        b.total_price,
        b.created_at,
        b.cancelled_at,
        m.title AS movie,
        DATE_FORMAT(sh.show_date, '%Y-%m-%d') AS show_date,
        TIME_FORMAT(sh.show_time, '%H:%i') AS show_time,
        sc.name AS screen_name,
        sc.label AS screen_label
      FROM bookings b
      JOIN shows sh ON sh.id = b.show_id
      JOIN movies m ON m.id = sh.movie_id
      JOIN screens sc ON sc.id = sh.screen_id
      WHERE b.booking_ref = ?
    `, [req.params.bookingRef]);

    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Booking reference not found."
      });
    }

    const booking = rows[0];

    const [seats] = await pool.execute(`
      SELECT seat_id, seat_price, status AS seat_status
      FROM booking_seats
      WHERE booking_id = ?
      ORDER BY seat_id
    `, [booking.booking_id]);

    res.json({
      success: true,
      booking,
      seats
    });
  } catch (error) {
    console.error("BOOKING LOOKUP ERROR:", error.code, error.message);
    res.status(500).json({
      success: false,
      message: "Could not retrieve booking."
    });
  }
});

// 7. Cancel a development booking
app.post("/api/bookings/:bookingRef/cancel", async (req, res) => {
  let connection;

  try {
    connection = await pool.getConnection();
    await connection.beginTransaction();

    const [rows] = await connection.execute(`
      SELECT id, status
      FROM bookings
      WHERE booking_ref = ?
      FOR UPDATE
    `, [req.params.bookingRef]);

    if (rows.length === 0) {
      await connection.rollback();
      return res.status(404).json({
        success: false,
        message: "Booking reference not found."
      });
    }

    if (rows[0].status !== "Confirmed") {
      await connection.rollback();
      return res.status(409).json({
        success: false,
        message: "This booking is already cancelled."
      });
    }

    await connection.execute(`
      UPDATE bookings
      SET status = 'Cancelled', cancelled_at = NOW()
      WHERE id = ?
    `, [rows[0].id]);

    // The existing database trigger releases active seats.
    await connection.commit();

    res.json({
      success: true,
      message: "Booking cancelled and seats released.",
      bookingRef: req.params.bookingRef
    });
  } catch (error) {
    if (connection) await connection.rollback();

    console.error("CANCELLATION ERROR:", error.code, error.message);

    res.status(500).json({
      success: false,
      message: "Could not cancel booking."
    });
  } finally {
    if (connection) connection.release();
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`CineVault running at http://localhost:${PORT}`);
});
