/**
 * CineVault Rating Fixer v7
 * Targeted follow-up to v6. Updates ONLY movies.rating for active movies with rating NULL/0. It uses
 * exact title/known alias + exact year + original-language match and at least
 * 3 TMDB votes. Lower vote counts are noted in the report as low-confidence.
 * Explicit bilingual exception: Thozha is the Tamil release/title of Oopiri.
 *
 * Run from the project folder: node CineVault_Rating_Fixer_v7.js
 */
'use strict';

require('dotenv').config();
const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

const TOKEN = process.env.TMDB_API_TOKEN;
const MIN_VOTES = 3;
const API_BASE = 'https://api.themoviedb.org/3';
const LANG_CODES = {
  English: 'en', Hindi: 'hi', Telugu: 'te', Tamil: 'ta', Kannada: 'kn',
  Malayalam: 'ml', Korean: 'ko'
};

// Alternate official/release titles for the remaining unresolved catalogue entries, including spellings exposed by v5 reports.
// These aliases only broaden searching; year and original language must still match except the explicitly documented Thozha/Oopiri bilingual release.
const ALIASES = {
  'catalog-0002': ['Baahubali 2: The Conclusion', 'Bahubali 2: The Conclusion', 'Bāhubali 2: The Conclusion', 'Baahubali: The Conclusion', 'Baahubali 2'],
  'catalog-0027': ['Salaar', 'Salaar: Part 1 - Ceasefire'],
  'catalog-0051': ['Attarintiki Daredi', 'Attarintiki Daaredi', 'Atharintiki Daaredi'],
  'catalog-0095': ['Swayam Krushi', 'Swayamkrushi'],
  'catalog-0119': ['HIT: The Second Case', 'HIT: The 2nd Case', 'HIT 2'],
  'catalog-0127': ['Yevade Subramanyam', 'Yevade Subramaniam', 'Yavade Subramanyam'],
  'catalog-0135': ['Tillu Square', 'DJ Tillu 2', '(Tillu)²'],
  'catalog-0168': ['Virata Parvam', 'Virataparvam', 'Viraata Parvam'],
  'catalog-0204': ['Lagaan', 'Lagaan: Once Upon a Time in India'],
  'catalog-0255': ['Taare Zameen Par', 'Like Stars on Earth'],
  'catalog-0385': ['Toilet: Ek Prem Katha', 'Toilet - A Love Story', 'Toilet: A Love Story'],
  'catalog-0820': ['Indian 2', 'Indian 2: Zero Tolerance'],
  'catalog-0839': ['Mouna Ragam', 'Mouna Raagam'],
  'catalog-0850': ['Aayutha Ezhuthu', 'Ayutha Ezhuthu', 'Aayitha Ezhuthu'],
  'catalog-0883': ['Friends', 'Friends Tamil'],
  'catalog-0932': ['Aarambam', 'Arrambam'],
  'catalog-0949': ['Marudhu', 'Maruthu'],
  'catalog-0951': ['Thozha', 'Oopiri'],
  'catalog-0975': ['Paava Kadhaigal', 'Paava Kadhaigal: Stories of Love'],
  'catalog-0986': ['Kadhalum Kadandhu Pogum', 'Kadhalum Kadanthu Pogum'],
  'catalog-1004': ['Kantara: Chapter 1', 'Kantara Chapter 1', 'Kantara: A Legend Chapter-1'],
  'catalog-1018': ['Sapta Sagaradaache Ello', 'Sapta Sagaradaache Ello - Side A', 'Sapta Sagaradaache Ello: Side A'],
  'catalog-1023': ['Duniya'],
  'catalog-1025': ['Jogi'],
  'catalog-1043': ['Baahubali', 'Baahubali: The Beginning', 'Bahubali: The Beginning'],
  'catalog-1140': ['Nadodikattu', 'Nadodikkattu', 'Nadodikaattu'],
  'catalog-1154': ['Aadujeevitham', 'The Goat Life'],
  'catalog-1230': ['Gangs of Wasseypur', 'Gangs of Wasseypur - Part 1'],
  'catalog-1231': ['Gangs of Wasseypur 2', 'Gangs of Wasseypur - Part 2'],
  'catalog-1415': ['Star Wars: Episode V - The Empire Strikes Back', 'The Empire Strikes Back'],
  'catalog-1537': ['Scream (2022)', 'Scream'],
  'catalog-1608': ['Kavalan', 'Kaavalan'],
  'catalog-1652': ['Sivaji', 'Sivaji: The Boss'],
  'catalog-1674': ['Velaiilla Pattadhari', 'Velailla Pattadhari', 'Velaiyilla Pattathari', 'Velai Illa Pattadhari', 'VIP'],
  'catalog-1675': ['Velaiilla Pattadhari 2', 'Velaiyilla Pattathari 2', 'Velai Illa Pattadhari 2', 'VIP 2'],
  'catalog-1706': ['Vagai Sooda Va', 'Vaagai Sooda Vaa'],
  'catalog-1746': ['Massu Engira Masilamani', 'Masss Engira Masilamani', 'Masss', 'Massu'],
  'catalog-1775': ['Seethakaathi', 'Seethakathi'],
  'catalog-1806': ['Alluda Majaka', 'Alluda Majaaka', 'Alludaa Majakaa'],
  'catalog-1818': ['Arya', 'Aarya'],
  'catalog-1819': ['Arya 2', 'Arya II', 'Aarya 2'],
  'catalog-1827': ['Racha', 'Rachcha'],
  'catalog-1830': ['Govindudu Andarivadele', 'Govindudu Andari Vaadele', 'Govindudu Andarivaadele', 'Govindudu Andhari Vaadele']
};

function normalize(value) {
  return String(value ?? '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}

function csvEscape(value) {
  const s = value === null || value === undefined ? '' : String(value);
  return `"${s.replace(/"/g, '""')}"`;
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function tmdbSearch(query, year) {
  const url = new URL(`${API_BASE}/search/movie`);
  url.searchParams.set('query', query);
  url.searchParams.set('include_adult', 'false');
  if (year) url.searchParams.set('year', String(year));
  let lastError;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const response = await fetch(url, {
        headers: { Authorization: `Bearer ${TOKEN}`, accept: 'application/json' }
      });
      if (response.status === 429 || response.status >= 500) {
        await delay(800 * (attempt + 1));
        continue;
      }
      if (!response.ok) {
        const body = await response.text();
        throw new Error(`TMDB HTTP ${response.status}: ${body.slice(0, 200)}`);
      }
      const data = await response.json();
      return Array.isArray(data.results) ? data.results : [];
    } catch (err) {
      lastError = err;
      if (attempt < 2) await delay(500 * (attempt + 1));
    }
  }
  throw lastError || new Error('TMDB search failed after retries');
}

// Paava Kadhaigal is catalogued as a movie here but TMDB may list the
// 2020 anthology in its TV catalogue. Search TV only for that specific ID.
async function tmdbTvSearch(query, year) {
  const url = new URL(`${API_BASE}/search/tv`);
  url.searchParams.set('query', query);
  url.searchParams.set('include_adult', 'false');
  if (year) url.searchParams.set('first_air_date_year', String(year));
  let lastError;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const response = await fetch(url, {
        headers: { Authorization: `Bearer ${TOKEN}`, accept: 'application/json' }
      });
      if (response.status === 429 || response.status >= 500) {
        await delay(800 * (attempt + 1));
        continue;
      }
      if (!response.ok) {
        const body = await response.text();
        throw new Error(`TMDB TV HTTP ${response.status}: ${body.slice(0, 200)}`);
      }
      const data = await response.json();
      return Array.isArray(data.results)
        ? data.results.map(item => ({ ...item, __tmdbType: 'tv' }))
        : [];
    } catch (err) {
      lastError = err;
      if (attempt < 2) await delay(500 * (attempt + 1));
    }
  }
  throw lastError || new Error('TMDB TV search failed after retries');
}

function displayTitle(movie) {
  return String(movie.title ?? movie.name ?? '');
}

function displayOriginalTitle(movie) {
  return String(movie.original_title ?? movie.original_name ?? '');
}

function getReleaseYear(movie) {
  const date = movie.release_date || movie.first_air_date || '';
  const n = Number(String(date).slice(0, 4));
  return Number.isFinite(n) && n > 0 ? n : null;
}

function dedupeMovies(items) {
  const byId = new Map();
  for (const m of items) {
    if (m && m.id !== undefined) byId.set(`${m.__tmdbType || 'movie'}:${m.id}`, m);
  }
  return [...byId.values()];
}

async function findSafeMatch(row) {
  const expectedLanguage = LANG_CODES[row.language];
  const expectedYear = Number(row.release_year);
  const aliases = [...new Set([String(row.title), ...(ALIASES[row.id] || [])])];
  const allowedTitles = new Set(aliases.map(normalize));
  let results = [];
  const failures = [];

  for (const alias of aliases) {
    const found = await tmdbSearch(alias, expectedYear);
    results = dedupeMovies(results.concat(found));
    // Short pause avoids hammering TMDB during a bulk run.
    await delay(120);
  }

  if (row.id === 'catalog-0975') {
    const tvResults = await tmdbTvSearch('Paava Kadhaigal', expectedYear);
    results = dedupeMovies(results.concat(tvResults));
  }

  const isThozhaOopiriBilingualMatch = m =>
    row.id === 'catalog-0951' && expectedYear === 2016 &&
    normalize(displayTitle(m)) === normalize('Oopiri') && m.original_language === 'te';

  const titleYearLanguage = results.filter(m => {
    const titleMatches = allowedTitles.has(normalize(displayTitle(m))) ||
      allowedTitles.has(normalize(displayOriginalTitle(m)));
    const correctYear = getReleaseYear(m) === expectedYear;
    const correctLanguage = m.original_language === expectedLanguage || isThozhaOopiriBilingualMatch(m);
    return titleMatches && correctYear && correctLanguage;
  });

  const eligible = titleYearLanguage
    .filter(m => Number(m.vote_count) >= MIN_VOTES && Number(m.vote_average) > 0)
    .sort((a, b) => Number(b.vote_count) - Number(a.vote_count));

  if (eligible.length) {
    const m = eligible[0];
    const bilingualNote = isThozhaOopiriBilingualMatch(m)
      ? ' Approved bilingual match: Thozha is the Tamil title/release of Oopiri; TMDB lists the record as Telugu-original.'
      : '';
    const mediaNote = m.__tmdbType === 'tv'
      ? ' Matched the exact title/year/language in TMDB TV catalogue (anthology/series entry).'
      : '';
    const lowVoteNote = Number(m.vote_count) < 5
      ? ' Low-confidence score because TMDB has fewer than 5 votes.'
      : '';
    return {
      match: m,
      reason: `Exact title/alias, year ${expectedYear}, language ${m.original_language}; ${m.vote_count} votes.${lowVoteNote}${bilingualNote}${mediaNote}`,
      alternatives: results.slice(0, 12).map(m => ({
        title: displayTitle(m), year: getReleaseYear(m), lang: m.original_language,
        votes: m.vote_count, rating: m.vote_average, type: m.__tmdbType || 'movie'
      }))
    };
  }

  if (titleYearLanguage.length) {
    const best = [...titleYearLanguage].sort((a, b) => Number(b.vote_count) - Number(a.vote_count))[0];
    failures.push(`Exact title/year/language candidate found, but only ${best.vote_count} vote(s); threshold is ${MIN_VOTES}.`);
  } else {
    failures.push('No exact title/alias match with the expected release year and original language.');
  }
  return {
    match: null,
    reason: failures.join(' '),
    alternatives: results.slice(0, 12).map(m => ({
      title: displayTitle(m), year: getReleaseYear(m), lang: m.original_language,
      votes: m.vote_count, rating: m.vote_average, type: m.__tmdbType || 'movie'
    }))
  };
}

async function main() {
  if (!TOKEN || TOKEN.includes('YOUR_') || TOKEN.length < 40) {
    throw new Error('TMDB_API_TOKEN is missing or looks like a placeholder in .env. Do not paste it into chat.');
  }
  const required = ['DB_HOST', 'DB_USER', 'DB_NAME'];
  const missing = required.filter(k => !process.env[k]);
  if (missing.length) throw new Error(`Missing database setting(s) in .env: ${missing.join(', ')}`);

  const connection = await mysql.createConnection({
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME,
    charset: 'utf8mb4',
    timezone: 'Z'
  });

  try {
    const [rows] = await connection.execute(
      `SELECT id, title, language, release_year, rating
       FROM movies
       WHERE is_active = 1 AND (rating IS NULL OR rating = 0)
       ORDER BY id`
    );
    const targets = rows;
    console.log(`Checking ${targets.length} active movie(s) with rating 0/NULL. This script changes ratings only.`);
    if (!targets.length) {
      console.log('Nothing to update — no active movies have rating 0/NULL.');
      return;
    }

    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupDir = path.join(process.cwd(), 'backups');
    const reportsDir = path.join(process.cwd(), 'reports');
    fs.mkdirSync(backupDir, { recursive: true });
    fs.mkdirSync(reportsDir, { recursive: true });
    const backupPath = path.join(backupDir, `cinevault-ratings-before-v7-${stamp}.json`);
    const reportPath = path.join(reportsDir, `cinevault-rating-fix-v7-${stamp}.csv`);
    fs.writeFileSync(backupPath, JSON.stringify(targets, null, 2), 'utf8');
    console.log(`Backup saved: ${path.relative(process.cwd(), backupPath)}`);

    const reportRows = [[
      'id', 'title', 'language', 'catalogue_year', 'status', 'tmdb_title',
      'tmdb_year', 'tmdb_language', 'vote_count', 'tmdb_rating', 'reason', 'alternatives'
    ]];
    let updated = 0, skipped = 0, errors = 0;

    for (let i = 0; i < targets.length; i++) {
      const row = targets[i];
      try {
        const result = await findSafeMatch(row);
        if (result.match) {
          const m = result.match;
          const rating = Math.round(Number(m.vote_average) * 10) / 10;
          const [updateResult] = await connection.execute(
            `UPDATE movies SET rating = ?
             WHERE id = ? AND is_active = 1 AND (rating IS NULL OR rating = 0)`,
            [rating, row.id]
          );
          if (updateResult.affectedRows > 0) {
            updated++;
            reportRows.push([
              row.id, row.title, row.language, row.release_year, 'UPDATED', displayTitle(m),
              getReleaseYear(m), m.original_language, m.vote_count, m.vote_average,
              result.reason, JSON.stringify(result.alternatives)
            ]);
          } else {
            skipped++;
            reportRows.push([
              row.id, row.title, row.language, row.release_year, 'SKIPPED', displayTitle(m),
              getReleaseYear(m), m.original_language, m.vote_count, m.vote_average,
              'Database row was already rated or inactive at update time; left unchanged.', JSON.stringify(result.alternatives)
            ]);
          }
        } else {
          skipped++;
          reportRows.push([
            row.id, row.title, row.language, row.release_year, 'SKIPPED', '', '', '', '', '',
            result.reason, JSON.stringify(result.alternatives)
          ]);
        }
      } catch (err) {
        errors++;
        reportRows.push([
          row.id, row.title, row.language, row.release_year, 'ERROR', '', '', '', '', '',
          err.message, '[]'
        ]);
      }
      if ((i + 1) % 10 === 0 || i + 1 === targets.length) {
        console.log(`Progress: ${i + 1}/${targets.length}; ratings updated ${updated}; skipped ${skipped}; errors ${errors}`);
      }
    }

    fs.writeFileSync(reportPath, reportRows.map(r => r.map(csvEscape).join(',')).join('\r\n'), 'utf8');
    console.log('\n=== CineVault rating-only fix v7 summary ===');
    console.log(`Rows checked: ${targets.length}`);
    console.log(`Ratings updated: ${updated}`);
    console.log(`Skipped (no safe match / too few votes): ${skipped}`);
    console.log(`Errors: ${errors}`);
    console.log(`Backup: ${path.relative(process.cwd(), backupPath)}`);
    console.log(`Review report: ${path.relative(process.cwd(), reportPath)}`);
    console.log('Only movies.rating was changed. No years, genres, posters, descriptions, shows, seats, or bookings were modified.');
  } finally {
    await connection.end();
  }
}

main().catch(err => {
  console.error('\nRating fixer stopped:', err.message);
  process.exitCode = 1;
});
